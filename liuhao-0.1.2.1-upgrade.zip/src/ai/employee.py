"""
AI Employee Module for LiuHao AI OS

Provides multi-agent coordination framework for complex task execution.
Supports agent pools, task distribution, result aggregation, and KPI reporting.
"""

from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from .providers import BaseProvider, get_provider

# 重依赖一律按需导入 —— 本模块会被 ``EmployeeStore`` 拉进名册读取路径，而名册
# 只需要 JSON 摘要。实测把 ``knowledge.memory``（mem0 → openai → qdrant_client）
# 与本模块的 observability 依赖放在顶层，会让首个 ``/v1/dashboard/roster``
# 请求付 6–12 秒的一次性导入成本。指标/追踪/长期记忆都只服务"真正执行任务"，
# 放到首次使用时再加载，语义不变，失败仍降级为无操作。
_metrics_module: Any = None
_tracing_module: Any = None


def _metrics():
    """首次调用时导入指标模块；不可用则永久降级为 None。"""
    global _metrics_module
    if _metrics_module is None:
        try:
            from ..observability import metrics as _impl
        except Exception:  # pragma: no cover - prometheus_client 可选
            _impl = None
        _metrics_module = _impl or False
    return _metrics_module or None


def track_agent_task(*args, **kwargs):
    module = _metrics()
    if module is None:
        return None
    return module.track_agent_task(*args, **kwargs)


def track_coordination(*args, **kwargs):
    module = _metrics()
    if module is None:
        return None
    return module.track_coordination(*args, **kwargs)


def _tracing():
    """首次调用时导入追踪模块；不可用则永久降级为 None。"""
    global _tracing_module
    if _tracing_module is None:
        try:
            from ..observability import tracing as _impl
        except Exception:  # pragma: no cover - OpenTelemetry 可选
            _impl = None
        _tracing_module = _impl or False
    return _tracing_module or None


def create_span(name: str, **kwargs):
    module = _tracing()
    if module is None:
        return None
    return module.create_span(name, **kwargs)


def end_span(span_context, error=None):
    module = _tracing()
    if module is None or span_context is None:
        return None
    return module.end_span(span_context, error=error)


def _span_attributes():
    module = _tracing()
    return module.AISpanAttributes if module is not None else None


class AgentStatus(Enum):
    """Agent execution status.

    Lifecycle (MASTER-SPEC Phase 3): create → run → pause → resume → stop → recover.
    """
    IDLE = "idle"              # created, ready to run
    BUSY = "busy"              # employee pool engaged on a goal (run-level)
    RUNNING = "running"        # actively executing a task
    PAUSED = "paused"          # suspended mid-flight, resumable
    STOPPED = "stopped"        # terminal stop, not resumable
    COMPLETED = "completed"    # task finished successfully
    FAILED = "failed"          # task raised an error
    RECOVERING = "recovering"  # restoring state from a checkpoint


class TaskStatus(Enum):
    """Task execution status."""
    PENDING = "pending"
    ASSIGNED = "assigned"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class Agent:
    """Represents an AI agent in the employee pool."""
    id: str
    agent_type: str
    name: str
    provider: BaseProvider
    system_prompt: str = ""
    status: AgentStatus = AgentStatus.IDLE
    current_task: Optional[str] = None
    completed_tasks: int = 0
    failed_tasks: int = 0
    total_latency_ms: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    checkpoint_state: Optional[Dict[str, Any]] = None
    #: 执行期按当前配置解析 provider（未显式注入实例时由 Employee 设置）。
    #: 不长期持有构建时的快照，否则控制台改 Key/改默认模型后仍用旧 Key。
    provider_resolver: Optional[Callable[[], BaseProvider]] = None

    def execute(self, task: str, **kwargs) -> Dict[str, Any]:
        """Execute a task using this agent's provider."""
        self.status = AgentStatus.RUNNING
        self.current_task = task
        start_time = time.time()

        # Use tracing if available（属性键同样按需取，避免顶层拉入 OTel SDK）
        span_attrs = _span_attributes()
        span = create_span(
            f"agent.execute.{self.agent_type}",
            attributes={
                span_attrs.AGENT_TYPE: self.agent_type,
                span_attrs.AGENT_TASK: task[:100],
            }
            if span_attrs is not None
            else {"agent_type": self.agent_type, "agent_task": task[:100]},
        )

        try:
            # Build prompt with system prompt
            full_prompt = f"{self.system_prompt}\n\nTask: {task}" if self.system_prompt else task

            # Generate response with retry（执行前按当前配置解析：
            # 控制台改 Key / 改默认模型后无需重启即可生效）。
            provider = (
                self.provider_resolver() if self.provider_resolver else self.provider
            )
            response = provider.generate_with_retry(full_prompt, **kwargs)

            latency_ms = (time.time() - start_time) * 1000
            self.total_latency_ms += latency_ms
            self.completed_tasks += 1
            self.status = AgentStatus.COMPLETED
            self.current_task = None

            # Track metrics
            track_agent_task(self.agent_type, "completed", latency_ms / 1000)

            if span:
                end_span(span)

            return {
                "agent_id": self.id,
                "agent_type": self.agent_type,
                "task": task,
                "result": response,
                "status": "completed",
                "latency_ms": latency_ms,
            }

        except Exception as e:
            latency_ms = (time.time() - start_time) * 1000
            self.total_latency_ms += latency_ms
            self.failed_tasks += 1
            self.status = AgentStatus.FAILED
            self.current_task = None

            # Track metrics
            track_agent_task(self.agent_type, "failed", latency_ms / 1000)

            if span:
                end_span(span, error=e)

            return {
                "agent_id": self.id,
                "agent_type": self.agent_type,
                "task": task,
                "result": str(e),
                "status": "failed",
                "latency_ms": latency_ms,
                "error": str(e),
            }

    def pause(self) -> bool:
        """Pause the agent if it is idle or running (lifecycle: pause)."""
        if self.status in (AgentStatus.IDLE, AgentStatus.RUNNING):
            self.status = AgentStatus.PAUSED
            return True
        return False

    def resume(self) -> bool:
        """Resume a paused agent (lifecycle: resume)."""
        if self.status == AgentStatus.PAUSED:
            self.status = AgentStatus.IDLE
            return True
        return False

    def stop(self) -> bool:
        """Stop the agent (terminal; not resumable — lifecycle: stop)."""
        self.status = AgentStatus.STOPPED
        self.current_task = None
        return True

    def checkpoint(self) -> Dict[str, Any]:
        """Snapshot current execution state for later recovery."""
        snapshot = {
            "status": self.status.value,
            "current_task": self.current_task,
            "completed_tasks": self.completed_tasks,
            "failed_tasks": self.failed_tasks,
            "total_latency_ms": self.total_latency_ms,
            "metadata": dict(self.metadata),
        }
        self.checkpoint_state = snapshot
        return snapshot

    def recover(self) -> bool:
        """Restore execution state from a checkpoint (lifecycle: recover)."""
        if self.checkpoint_state is None:
            return False
        self.status = AgentStatus.RECOVERING
        self.current_task = self.checkpoint_state.get("current_task")
        self.completed_tasks = int(self.checkpoint_state.get("completed_tasks", 0))
        self.failed_tasks = int(self.checkpoint_state.get("failed_tasks", 0))
        self.total_latency_ms = float(self.checkpoint_state.get("total_latency_ms", 0.0))
        meta = self.checkpoint_state.get("metadata")
        if isinstance(meta, dict):
            self.metadata = dict(meta)
        self.status = AgentStatus.IDLE
        return True


@dataclass
class Task:
    """Represents a task to be executed by agents."""
    id: str
    description: str
    task_type: str = "general"
    priority: int = 0
    depends_on: List[str] = field(default_factory=list)
    status: TaskStatus = TaskStatus.PENDING
    assigned_agent: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None


class Employee:
    """
    AI Employee - Coordinates multiple agents for complex task execution.

    Features:
    - Agent pool management with different agent types
    - Task distribution with dependency resolution
    - Result aggregation
    - KPI reporting
    - Observability integration (metrics, tracing, memory)
    """

    #: ``employment_status`` 的合法取值：在职 / 停用。
    ACTIVE = "active"
    DISABLED = "disabled"

    def __init__(
        self,
        name: str,
        provider: Optional[BaseProvider] = None,
        agent_count: int = 3,
        agent_types: Optional[List[str]] = None,
        system_prompts: Optional[Dict[str, str]] = None,
        enable_observability: bool = True,
        role_description: str = "",
        default_capabilities: Optional[List[str]] = None,
        owner_account_id: str = "",
        employment_status: str = "active",
        employee_id: str = "",
        last_activity: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize an Employee.

        Args:
            name: Employee name
            provider: AI provider (defaults to global provider)
            agent_count: Number of agents to create
            agent_types: List of agent types (defaults to ["general"] * agent_count)
            system_prompts: Custom system prompts per agent type
            enable_observability: Enable metrics/tracing/memory integration
            role_description: 职责描述（人可读）
            default_capabilities: 默认能力（已注册执行器的 capability id）
            owner_account_id: 归属账号（决定谁能看到/改/派活）
            employment_status: ``active``（在职）/ ``disabled``（停用）
            employee_id: 稳定员工 id（改名不变，用于记忆归属等跨改名关联）
            last_activity: 最后一次活动的可读快照
                ``{"description", "outcome", "at"}``
        """
        self.name = name
        # 稳定 id 与名字解耦：改名不会让历史记忆/关联断线。老数据没有这个字段，
        # 由 ``stable_id()`` 退回名字（行为与以前一致）。
        self.employee_id = employee_id or ""
        self.last_activity: Dict[str, Any] = dict(last_activity or {})
        self.provider = provider or get_provider()
        # 未显式注入 provider 时，执行期按当前模型配置重新解析：控制台改 Key /
        # 改默认模型后无需重启，也不会长期持有一个构建时的旧实例。
        self._provider_resolver: Optional[Callable[[], BaseProvider]] = (
            None if provider is not None else get_provider
        )
        self.agent_count = agent_count
        self.agent_types = agent_types or ["general"] * agent_count
        self.system_prompts = system_prompts or {}
        self.enable_observability = enable_observability
        # 员工实体字段（不只是"agent 池"）：职责、默认能力、归属账号、在职状态。
        # 这些字段全部持久化，因此重启后仍是同一个"员工"，不是重新生成的编号。
        self.role_description = role_description or ""
        self.default_capabilities = list(default_capabilities or [])
        self.owner_account_id = owner_account_id or ""
        self.employment_status = (
            employment_status
            if employment_status in (self.ACTIVE, self.DISABLED)
            else self.ACTIVE
        )

        # Validate agent_types length
        if len(self.agent_types) < agent_count:
            # Repeat the last type
            self.agent_types = self.agent_types + [self.agent_types[-1]] * (agent_count - len(self.agent_types))

        # Create agents
        self.agents: Dict[str, Agent] = {}
        self._create_agents()

        # Task management
        self.tasks: Dict[str, Task] = {}
        self.task_queue: List[str] = []
        self.completed_tasks: List[str] = []
        self.failed_tasks: List[str] = []

        # Metrics
        self.total_tasks_submitted = 0
        self.total_tasks_completed = 0
        self.total_tasks_failed = 0

        # Goal-level metrics (real execution binding): each goal submitted to /
        # completed / failed by this employee. Drives roster / KPI so the
        # "autonomous worker" actually shows up in the numbers, not just tasks.
        self.total_goals_submitted = 0
        self.total_goals_completed = 0
        self.total_goals_failed = 0
        self.goals: List[str] = []

        # Observability（长期记忆只在启用可观测性的员工上按需加载：
        # mem0/openai/qdrant_client 的首次导入成本不应落在名册读取路径上）
        if self.enable_observability:
            from ..knowledge.memory import create_memory_manager

            self._memory = create_memory_manager(user_id=f"employee_{name}", use_mem0=False)
        else:
            self._memory = None

    def _create_agents(self):
        """Create agent pool."""
        for i in range(self.agent_count):
            agent_type = self.agent_types[i]
            # Globally-unique id (prefixed by employee name) so that an agent can
            # be addressed by id across multiple employees without collision --
            # required for by-name pause/resume in AIStateManager. Previously
            # every employee used the same ``agent_0``/``agent_1``/... ids, which
            # made ``pause_agent(agent_id)`` ambiguous once more than one
            # employee existed.
            agent_id = f"{self.name}-a{i}"
            system_prompt = self.system_prompts.get(agent_type, "")

            agent = Agent(
                id=agent_id,
                agent_type=agent_type,
                name=f"{self.name}-{agent_type}-{i}",
                provider=self.provider,
                provider_resolver=self._provider_resolver,
                system_prompt=system_prompt,
            )
            self.agents[agent_id] = agent

    def is_active(self) -> bool:
        """在职员工才接受派活；停用只是"还在名册里，但不再接活"。"""
        return self.employment_status == self.ACTIVE

    # ── 可读状态 / 最后一次活动 ──

    #: ``current_status()`` 的取值：空闲 / 执行中 / 出错 / 已完成 / 已停用。
    STATUS_IDLE = "idle"
    STATUS_RUNNING = "running"
    STATUS_ERROR = "error"
    STATUS_COMPLETED = "completed"
    STATUS_DISABLED = "disabled"

    def stable_id(self) -> str:
        """跨改名稳定的员工 id（老数据没有 id 时退回名字）。"""
        return self.employee_id or self.name

    def record_activity(
        self, description: str, outcome: str, when: Optional[float] = None
    ) -> None:
        """记录"最后一次做了什么、什么时候、结果如何"（人可读，不含内部 id）。"""
        self.last_activity = {
            "description": str(description or "")[:500],
            "outcome": str(outcome or ""),
            "at": float(when if when is not None else time.time()),
        }

    def current_status(self) -> str:
        """员工当前状态：停用 > 执行中 > 上一次结果（出错/已完成）> 空闲。

        执行中来自 agent 的真实 BUSY/RUNNING 状态；否则用最后一次活动的结果，
        避免"跑完了界面还说空闲"。没有活动记录时就是空闲。
        """
        if self.employment_status == self.DISABLED:
            return self.STATUS_DISABLED
        if any(
            agent.status in (AgentStatus.BUSY, AgentStatus.RUNNING)
            for agent in self.agents.values()
        ):
            return self.STATUS_RUNNING
        outcome = str((self.last_activity or {}).get("outcome") or "").lower()
        if outcome in ("failed", "error"):
            return self.STATUS_ERROR
        if outcome in ("completed", "cancelled"):
            return self.STATUS_COMPLETED
        return self.STATUS_IDLE

    def add_task(self, description: str, task_type: str = "general",
                 priority: int = 0, depends_on: Optional[List[str]] = None) -> str:
        """Add a task to the queue."""
        task_id = f"task_{len(self.tasks)}"
        task = Task(
            id=task_id,
            description=description,
            task_type=task_type,
            priority=priority,
            depends_on=depends_on or [],
        )
        self.tasks[task_id] = task
        self.task_queue.append(task_id)
        self.total_tasks_submitted += 1
        return task_id

    # ── Goal-level binding (real autonomous-worker accounting) ──

    def mark_agents_busy(self) -> None:
        """Mark every idle agent BUSY while this employee works a goal.

        Only touches agents that are IDLE/BUSY so it never clobbers a
        paused/resumed agent mid-lifecycle (important for the pause/resume
        endpoint's semantics).
        """
        for agent in self.agents.values():
            if agent.status in (AgentStatus.IDLE, AgentStatus.BUSY):
                agent.status = AgentStatus.BUSY

    def mark_agents_idle(self) -> None:
        """Release the goal-level BUSY flag back to IDLE once the goal ends."""
        for agent in self.agents.values():
            if agent.status == AgentStatus.BUSY:
                agent.status = AgentStatus.IDLE

    def record_goal_submitted(self, goal_id: str) -> None:
        """Register a goal as submitted (counted once per goal_id)."""
        if goal_id not in self.goals:
            self.goals.append(goal_id)
            self.total_goals_submitted += 1

    def record_goal_finished(self, goal_id: str, state: str) -> None:
        """Account a goal's terminal outcome in the employee KPI.

        ``state`` is the AgentRunState value ("completed" / "failed" /
        "cancelled"). A cancelled goal counts as failed for KPI purposes.
        """
        self.record_goal_submitted(goal_id)
        if state == "completed":
            self.total_goals_completed += 1
        elif state in ("failed", "cancelled"):
            self.total_goals_failed += 1

    def add_tasks(self, tasks: List[Dict[str, Any]]) -> List[str]:
        """Add multiple tasks at once."""
        task_ids = []
        for task_data in tasks:
            task_id = self.add_task(
                description=task_data.get("description", ""),
                task_type=task_data.get("type", "general"),
                priority=task_data.get("priority", 0),
                depends_on=task_data.get("depends_on"),
            )
            task_ids.append(task_id)
        return task_ids

    def distribute_tasks(self, tasks: Optional[List[str]] = None) -> Dict[str, str]:
        """
        Distribute tasks to available agents.

        Args:
            tasks: Specific task IDs to distribute (defaults to all pending)

        Returns:
            Mapping of agent_id -> task_id
        """
        if tasks is None:
            tasks = [t for t in self.task_queue if self.tasks[t].status == TaskStatus.PENDING]

        distribution = {}
        available_agents = [a for a in self.agents.values() if a.status == AgentStatus.IDLE]

        for i, task_id in enumerate(tasks):
            if i >= len(available_agents):
                break  # No more available agents

            agent = available_agents[i]
            task = self.tasks[task_id]

            # Check dependencies
            if not self._dependencies_met(task):
                continue

            task.status = TaskStatus.ASSIGNED
            task.assigned_agent = agent.id
            agent.current_task = task_id
            distribution[agent.id] = task_id

        return distribution

    def _dependencies_met(self, task: Task) -> bool:
        """Check if all task dependencies are completed."""
        for dep_id in task.depends_on:
            if dep_id not in self.tasks:
                return False
            if self.tasks[dep_id].status != TaskStatus.COMPLETED:
                return False
        return True

    def execute_tasks(self, tasks: Optional[List[str]] = None, max_workers: int = None) -> Dict[str, Any]:
        """
        Execute distributed tasks in parallel.

        Args:
            tasks: Task IDs to execute (defaults to all assigned)
            max_workers: Maximum parallel workers

        Returns:
            Aggregated results
        """
        if tasks is None:
            tasks = [t for t in self.task_queue if self.tasks[t].status == TaskStatus.ASSIGNED]

        max_workers = max_workers or len(self.agents)
        results = {}

        # Track coordination start
        if self.enable_observability:
            track_coordination("distribute", "started")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_task = {}

            for task_id in tasks:
                task = self.tasks[task_id]
                if task.status != TaskStatus.ASSIGNED:
                    continue

                agent = self.agents.get(task.assigned_agent)
                if not agent:
                    continue

                task.status = TaskStatus.RUNNING
                task.started_at = time.time()

                future = executor.submit(agent.execute, task.description)
                future_to_task[future] = (task_id, agent.id)

            for future in as_completed(future_to_task):
                task_id, agent_id = future_to_task[future]
                try:
                    result = future.result()
                    task = self.tasks[task_id]
                    task.result = result
                    task.status = TaskStatus.COMPLETED if result["status"] == "completed" else TaskStatus.FAILED
                    task.completed_at = time.time()

                    if task.status == TaskStatus.COMPLETED:
                        self.completed_tasks.append(task_id)
                        self.total_tasks_completed += 1
                    else:
                        self.failed_tasks.append(task_id)
                        self.total_tasks_failed += 1

                    results[task_id] = result

                    # Persist to memory
                    if self.enable_observability and self._memory:
                        from ..knowledge.memory import MemoryTier

                        self._memory.remember(
                            content=f"Task {task_id}: {task.description}",
                            tier=MemoryTier.EPISODIC,
                            importance=0.7,
                            tags=["task", task.status.value],
                            metadata={"task_id": task_id, "result": str(result)[:500]}
                        )

                except Exception as e:
                    task = self.tasks[task_id]
                    task.status = TaskStatus.FAILED
                    task.completed_at = time.time()
                    self.failed_tasks.append(task_id)
                    self.total_tasks_failed += 1
                    results[task_id] = {
                        "agent_id": agent_id,
                        "task": task.description,
                        "result": str(e),
                        "status": "failed",
                        "error": str(e),
                    }

        # Track coordination complete
        if self.enable_observability:
            track_coordination("execute", "completed")

        return results

    def aggregate_results(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Aggregate results from multiple agent executions.

        Args:
            results: Results from execute_tasks()

        Returns:
            Aggregated summary
        """
        completed = [r for r in results.values() if r.get("status") == "completed"]
        failed = [r for r in results.values() if r.get("status") == "failed"]

        all_results = []
        for r in completed:
            all_results.append(r.get("result", ""))

        return {
            "employee": self.name,
            "total_agents": len(self.agents),
            "total_tasks": len(results),
            "completed": len(completed),
            "failed": len(failed),
            "success_rate": len(completed) / len(results) * 100 if results else 0,
            "results": all_results,
            "errors": [r.get("error") for r in failed if r.get("error")],
            "avg_latency_ms": sum(r.get("latency_ms", 0) for r in results.values()) / len(results) if results else 0,
        }

    def generate_kpi_report(self) -> Dict[str, Any]:
        """Generate KPI report for this employee."""
        total = self.total_tasks_completed + self.total_tasks_failed
        success_rate = (self.total_tasks_completed / total * 100) if total > 0 else 0

        # Agent-level stats
        agent_stats = {}
        for agent_id, agent in self.agents.items():
            agent_total = agent.completed_tasks + agent.failed_tasks
            agent_stats[agent_id] = {
                "agent_type": agent.agent_type,
                "completed": agent.completed_tasks,
                "failed": agent.failed_tasks,
                "success_rate": (agent.completed_tasks / agent_total * 100) if agent_total > 0 else 0,
                "avg_latency_ms": (agent.total_latency_ms / agent_total) if agent_total > 0 else 0,
            }

        return {
            "employee_name": self.name,
            "agent_count": self.agent_count,
            "agent_types": self.agent_types,
            "total_tasks_submitted": self.total_tasks_submitted,
            "completed_tasks": self.total_tasks_completed,
            "failed_tasks": self.total_tasks_failed,
            "success_rate": success_rate,
            "agent_stats": agent_stats,
            "pending_tasks": len([t for t in self.tasks.values() if t.status == TaskStatus.PENDING]),
            "running_tasks": len([t for t in self.tasks.values() if t.status == TaskStatus.RUNNING]),
        }

    def get_agent_status(self) -> Dict[str, Any]:
        """Get status of all agents."""
        return {
            agent_id: {
                "agent_type": agent.agent_type,
                "status": agent.status.value,
                "current_task": agent.current_task,
                "completed": agent.completed_tasks,
                "failed": agent.failed_tasks,
            }
            for agent_id, agent in self.agents.items()
        }

    def run_workflow(self, tasks: List[Dict[str, Any]], max_workers: int = None) -> Dict[str, Any]:
        """
        Run a complete workflow: add tasks, distribute, execute, aggregate.

        Args:
            tasks: List of task dicts with description, type, priority, depends_on
            max_workers: Maximum parallel workers

        Returns:
            Complete workflow results
        """
        # Add all tasks
        task_ids = self.add_tasks(tasks)

        # Distribute and execute in dependency order
        all_results = {}
        remaining_tasks = set(task_ids)

        while remaining_tasks:
            # Find tasks with met dependencies
            ready_tasks = [
                t for t in remaining_tasks
                if self._dependencies_met(self.tasks[t])
            ]

            if not ready_tasks:
                # Check for circular dependency or all failed
                break

            # Distribute ready tasks
            distribution = self.distribute_tasks(ready_tasks)

            # Execute
            executed_tasks = list(distribution.values())
            results = self.execute_tasks(executed_tasks, max_workers)
            all_results.update(results)

            # Remove completed from remaining
            remaining_tasks -= set(executed_tasks)

        # Aggregate
        aggregated = self.aggregate_results(all_results)
        aggregated["kpi"] = self.generate_kpi_report()
        aggregated["task_details"] = all_results

        return aggregated


class AgentPool:
    """Manages a pool of employees for large-scale coordination."""

    def __init__(self, name: str):
        self.name = name
        self.employees: Dict[str, Employee] = {}

    def add_employee(self, employee: Employee) -> None:
        """Add an employee to the pool."""
        self.employees[employee.name] = employee

    def remove_employee(self, name: str) -> bool:
        """Remove an employee from the pool."""
        if name in self.employees:
            del self.employees[name]
            return True
        return False

    def get_employee(self, name: str) -> Optional[Employee]:
        """Get an employee by name."""
        return self.employees.get(name)

    def distribute_workload(self, tasks: List[Dict[str, Any]]) -> Dict[str, List[str]]:
        """Distribute tasks across employees based on capacity."""
        # Simple round-robin for now
        employee_names = list(self.employees.keys())
        if not employee_names:
            return {}

        distribution = {name: [] for name in employee_names}
        for i, task in enumerate(tasks):
            emp_name = employee_names[i % len(employee_names)]
            distribution[emp_name].append(task)

        return distribution

    def execute_parallel(self, tasks: List[Dict[str, Any]], max_workers: int = None) -> Dict[str, Any]:
        """Execute tasks across all employees in parallel."""
        distribution = self.distribute_workload(tasks)
        all_results = {}

        with ThreadPoolExecutor(max_workers=max_workers or len(self.employees)) as executor:
            future_to_emp = {}

            for emp_name, emp_tasks in distribution.items():
                employee = self.employees[emp_name]
                future = executor.submit(employee.run_workflow, emp_tasks)
                future_to_emp[future] = emp_name

            for future in as_completed(future_to_emp):
                emp_name = future_to_emp[future]
                try:
                    result = future.result()
                    all_results[emp_name] = result
                except Exception as e:
                    all_results[emp_name] = {"error": str(e)}

        return all_results

    def aggregate_pool_kpi(self) -> Dict[str, Any]:
        """Aggregate KPIs across all employees."""
        total_submitted = 0
        total_completed = 0
        total_failed = 0

        employee_kpis = {}
        for name, emp in self.employees.items():
            kpi = emp.generate_kpi_report()
            employee_kpis[name] = kpi
            total_submitted += kpi["total_tasks_submitted"]
            total_completed += kpi["completed_tasks"]
            total_failed += kpi["failed_tasks"]

        return {
            "pool_name": self.name,
            "employee_count": len(self.employees),
            "total_tasks_submitted": total_submitted,
            "total_completed": total_completed,
            "total_failed": total_failed,
            "overall_success_rate": (total_completed / (total_completed + total_failed) * 100)
            if (total_completed + total_failed) > 0 else 0,
            "employee_kpis": employee_kpis,
        }
