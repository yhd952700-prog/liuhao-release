"""Event Kernel — Unified Event Bus + Correlation IDs

The Event Kernel provides a unified event bus for inter-kernel
communication and cross-cutting concerns. All events carry correlation
IDs for end-to-end traceability.

依据 Definition Lock §112: Event Kernel 必须能够
- Publish events to typed channels
- Subscribe to events with scope filtering
- Maintain correlation IDs across event chains
- Support event replay and dead letter handling
- Provide ordering guarantees per correlation ID
"""
from __future__ import annotations
from src.kernels._base import (
    KernelLifecycle,
    KernelNotServableError,
    KernelStateError,
    is_servable,
)

from dataclasses import dataclass, field
from datetime import datetime
from src._time import utc_now
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set
from collections import defaultdict
import uuid
import threading

from src.kernels._crosscutting import kernel_action


class EventScope(str, Enum):
    """Event permission scope L0-L7."""
    L0 = "L0"  # Human only
    L1 = "L1"
    L2 = "L2"
    L3 = "L3"
    L4 = "L4"
    L5 = "L5"
    L6 = "L6"
    L7 = "L7"  # Full autonomy


class EventPriority(str, Enum):
    """Event priority levels."""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class Event:
    """Unified event structure with correlation ID."""
    type: str
    source: str
    data: Any = None
    correlation_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    causation_id: Optional[str] = None  # ID of event that caused this one
    scope: EventScope = EventScope.L0
    priority: EventPriority = EventPriority.NORMAL
    timestamp: datetime = field(default_factory=utc_now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: Set[str] = field(default_factory=set)

    def __post_init__(self):
        if self.causation_id is None:
            self.causation_id = self.correlation_id

    def with_correlation(self, correlation_id: str) -> "Event":
        """Create a new event with same correlation chain."""
        new_event = Event(
            type=self.type,
            source=self.source,
            data=self.data,
            correlation_id=correlation_id,
            causation_id=self.correlation_id,
            scope=self.scope,
            priority=self.priority,
            metadata=self.metadata.copy(),
            tags=self.tags.copy(),
        )
        return new_event


@dataclass
class Subscription:
    """Event subscription with handler and filters."""
    id: str
    event_type: str
    handler: Callable[[Event], None]
    scope: EventScope = EventScope.L0
    filters: Dict[str, Any] = field(default_factory=dict)
    correlation_filter: Optional[str] = None
    created_at: datetime = field(default_factory=utc_now)
    active: bool = True

    def matches(self, event: Event) -> bool:
        """Check if event matches this subscription."""
        if not self.active:
            return False
        if self.event_type != "*" and self.event_type != event.type:
            return False

        # Scope check: subscription scope must be >= event scope
        scope_order = {s: i for i, s in enumerate(EventScope)}
        if scope_order[self.scope] < scope_order[event.scope]:
            return False

        # Correlation filter
        if self.correlation_filter and self.correlation_filter != event.correlation_id:
            return False

        # Custom filters
        for key, value in self.filters.items():
            if key not in event.metadata or event.metadata[key] != value:
                return False

        return True


class DeadLetterEntry:
    """Failed event for retry/analysis."""

    def __init__(
        self,
        event: Event,
        error: Exception,
        subscription_id: str,
        attempt: int = 1
    ):
        self.event = event
        self.error = error
        self.subscription_id = subscription_id
        self.attempt = attempt
        self.timestamp = utc_now()
        self.resolved = False


class EventBus:
    """Unified event bus with correlation ID tracking."""
    lifecycle: KernelLifecycle = KernelLifecycle.UNINITIALIZED

    def __init__(self):
        self._subscriptions: Dict[str, List[Subscription]] = defaultdict(list)
        self._event_history: List[Event] = []
        self._max_history = 10000
        # 长跑实测 RSS +24.5MB/h：`_event_history` 有上限，但它旁边的
        # `_correlation_index` 没有——每条事件都按 correlation_id 再挂一份强引用，
        # 历史被裁掉后旧 Event（含 payload）仍被索引钉住，等于"只增不删"。
        # 这里让索引跟随历史窗口回收，并给死信一个上限（PAUSED 状态下每次发布
        # 都会记一条死信，不设限同样会单调上涨）。
        self._max_dead_letters = 1000
        self._dead_letters: List[DeadLetterEntry] = []
        self._lock = threading.RLock()
        self._correlation_index: Dict[str, List[Event]] = defaultdict(list)

    def _append_dead_letter(self, entry: DeadLetterEntry) -> None:
        """记录死信并保持有界（调用方已持有 ``self._lock``）。"""
        self._dead_letters.append(entry)
        overflow = len(self._dead_letters) - self._max_dead_letters
        if overflow > 0:
            del self._dead_letters[:overflow]

    @kernel_action("event.publish")
    def publish(self, event: Event) -> str:
        """Publish an event to all matching subscribers.

        Lifecycle gate: a PAUSED / STOPPED bus refuses the publish and records
        the event as a dead letter, so the refusal is visible in
        ``stats()["dead_letters_total"]`` instead of vanishing. It previously
        only flipped a flag and kept delivering to subscribers, so "paused" was
        a label rather than a behaviour.
        """
        with self._lock:
            if not is_servable(self):
                self._append_dead_letter(
                    DeadLetterEntry(
                        event,
                        KernelNotServableError(
                            f"event bus is {self.lifecycle.value}"
                        ),
                        "lifecycle-gate",
                    )
                )
                raise KernelNotServableError(
                    f"EventBus.publish refused: event bus is {self.lifecycle.value}"
                )

            # Store in history
            self._event_history.append(event)
            if len(self._event_history) > self._max_history:
                evicted = self._event_history[: len(self._event_history) - self._max_history]
                self._event_history = self._event_history[-self._max_history:]
                # 同步从相关性索引里摘掉被淘汰的事件；否则索引会永远钉住旧
                # Event（payload 全在内存里），RSS 只增不降（长跑 +24.5MB/h）。
                for old in evicted:
                    bucket = self._correlation_index.get(old.correlation_id)
                    if not bucket:
                        continue
                    bucket[:] = [kept for kept in bucket if kept is not old]
                    if not bucket:
                        self._correlation_index.pop(old.correlation_id, None)

            # Index by correlation ID
            self._correlation_index[event.correlation_id].append(event)

            # Find matching subscriptions.
            #
            # ``self._subscriptions`` is a defaultdict(list), so
            # ``.get(event.type, [])`` returns the stored list *itself*.
            # Extending it in place (the old code) appended the wildcard
            # subscriptions to the type's own list on every publish: the list
            # grew without bound and each wildcard handler was invoked once per
            # accumulated copy. Build a fresh, id-de-duplicated list instead.
            subscriptions: List[Subscription] = []
            _seen_ids: set = set()
            for candidate in (
                *self._subscriptions.get(event.type, ()),
                *self._subscriptions.get("*", ()),
            ):
                if candidate.id not in _seen_ids:
                    _seen_ids.add(candidate.id)
                    subscriptions.append(candidate)

            for sub in subscriptions:
                if sub.matches(event):
                    try:
                        sub.handler(event)
                    except Exception as e:
                        # Dead letter handling
                        dl = DeadLetterEntry(event, e, sub.id)
                        self._append_dead_letter(dl)

            return event.correlation_id

    def publish_async(self, event: Event) -> str:
        """Publish event asynchronously (fire and forget)."""
        # In production, this would use a thread pool or async queue
        return self.publish(event)

    @kernel_action("event.subscribe")
    def subscribe(
        self,
        event_type: str,
        handler: Callable[[Event], None],
        scope: EventScope = EventScope.L0,
        filters: Optional[Dict[str, Any]] = None,
        correlation_id: Optional[str] = None
    ) -> str:
        """Subscribe to events. Returns subscription ID."""
        sub = Subscription(
            id=str(uuid.uuid4()),
            event_type=event_type,
            handler=handler,
            scope=scope,
            filters=filters or {},
            correlation_filter=correlation_id,
        )
        with self._lock:
            self._subscriptions[event_type].append(sub)
        return sub.id

    @kernel_action("event.unsubscribe")
    def unsubscribe(self, subscription_id: str) -> bool:
        """Unsubscribe by ID."""
        with self._lock:
            for event_type, subs in self._subscriptions.items():
                for i, sub in enumerate(subs):
                    if sub.id == subscription_id:
                        subs.pop(i)
                        return True
        return False

    def get_subscriptions(self, event_type: Optional[str] = None) -> List[Subscription]:
        """Get all subscriptions, optionally filtered by event type."""
        with self._lock:
            if event_type:
                return list(self._subscriptions.get(event_type, []))
            result = []
            for subs in self._subscriptions.values():
                result.extend(subs)
            return result

    def get_event_history(
        self,
        correlation_id: Optional[str] = None,
        event_type: Optional[str] = None,
        since: Optional[datetime] = None,
        limit: int = 100
    ) -> List[Event]:
        """Get event history with filters."""
        with self._lock:
            if correlation_id:
                events = self._correlation_index.get(correlation_id, [])
            else:
                events = self._event_history

            if event_type:
                events = [e for e in events if e.type == event_type]
            if since:
                events = [e for e in events if e.timestamp >= since]

            return events[-limit:]

    def get_correlation_chain(self, correlation_id: str) -> List[Event]:
        """Get full event chain for a correlation ID."""
        with self._lock:
            return list(self._correlation_index.get(correlation_id, []))

    def get_dead_letters(self, unresolved_only: bool = True) -> List[DeadLetterEntry]:
        """Get dead letter events."""
        with self._lock:
            if unresolved_only:
                return [dl for dl in self._dead_letters if not dl.resolved]
            return list(self._dead_letters)

    @kernel_action("event.retry_dead_letter")
    def retry_dead_letter(self, index: int) -> bool:
        """Re-dispatch a dead-lettered handler, honestly reporting the outcome.

        ``publish`` swallows handler exceptions and only appends a NEW dead
        letter for the *same event object* when the handler fails again, so a
        naive ``return True`` after ``publish`` would claim success while the
        handler actually failed a second time. We compare the dead-letter count
        before/after re-publish: if a fresh dead letter for this exact event
        appeared, the re-dispatch failed and we must report ``False`` (and must
        NOT mark it resolved). Only when no new failure was recorded do we
        consider the re-dispatch successful.
        """
        with self._lock:
            if 0 <= index < len(self._dead_letters):
                dl = self._dead_letters[index]
                dl.attempt += 1
                before = len(self._dead_letters)
                try:
                    self.publish(dl.event)
                except Exception:
                    # publish itself raised (transport-level failure).
                    return False
                re_failed = any(
                    e.event is dl.event for e in self._dead_letters[before:]
                )
                if re_failed:
                    # The handler raised again; a new dead letter proves it.
                    return False
                dl.resolved = True
                return True
        return False

    @kernel_action("event.clear_history")
    def clear_history(self) -> None:
        """Clear event history (use with caution)."""
        with self._lock:
            self._event_history.clear()
            self._correlation_index.clear()

    def stats(self) -> Dict[str, Any]:
        """Get bus statistics."""
        with self._lock:
            return {
                "total_subscriptions": sum(len(s) for s in self._subscriptions.values()),
                "subscription_types": len(self._subscriptions),
                "event_history_size": len(self._event_history),
                "dead_letters_total": len(self._dead_letters),
                "dead_letters_unresolved": len([dl for dl in self._dead_letters if not dl.resolved]),
                "correlation_chains": len(self._correlation_index),
            }

    def initialize(self) -> None:
        self.lifecycle = KernelLifecycle.READY

    def shutdown(self) -> None:
        self.lifecycle = KernelLifecycle.STOPPED

    def pause(self) -> None:
        if self.lifecycle not in (KernelLifecycle.READY, KernelLifecycle.UNINITIALIZED):
            raise KernelStateError(f"cannot pause from {self.lifecycle}")
        self.lifecycle = KernelLifecycle.PAUSED

    def resume(self) -> None:
        if self.lifecycle is not KernelLifecycle.PAUSED:
            raise KernelStateError(f"cannot resume from {self.lifecycle}")
        self.lifecycle = KernelLifecycle.READY


# Global event bus instance
_global_bus: Optional[EventBus] = None
_global_lock = threading.Lock()


def get_event_bus() -> EventBus:
    """Get or create the global event bus."""
    global _global_bus
    if _global_bus is None:
        with _global_lock:
            if _global_bus is None:
                _global_bus = EventBus()
                _global_bus.initialize()  # 存在即 READY：构造完成即视为就绪
    return _global_bus


# Convenience functions
def publish_event(
    type: str,
    source: str,
    data: Any = None,
    correlation_id: Optional[str] = None,
    causation_id: Optional[str] = None,
    scope: EventScope = EventScope.L0,
    priority: EventPriority = EventPriority.NORMAL,
    metadata: Optional[Dict[str, Any]] = None,
    tags: Optional[Set[str]] = None
) -> str:
    """Publish an event with convenience parameters."""
    event = Event(
        type=type,
        source=source,
        data=data,
        correlation_id=correlation_id or str(uuid.uuid4()),
        causation_id=causation_id,
        scope=scope,
        priority=priority,
        metadata=metadata or {},
        tags=tags or set(),
    )
    return get_event_bus().publish(event)


def subscribe_event(
    event_type: str,
    handler: Callable[[Event], None],
    scope: EventScope = EventScope.L0,
    filters: Optional[Dict[str, Any]] = None,
    correlation_id: Optional[str] = None
) -> str:
    """Subscribe to events with convenience parameters."""
    return get_event_bus().subscribe(event_type, handler, scope, filters, correlation_id)


def get_event_chain(correlation_id: str) -> List[Event]:
    """Get full event chain for correlation ID."""
    return get_event_bus().get_correlation_chain(correlation_id)


def create_correlation_id() -> str:
    """Generate a new correlation ID."""
    return str(uuid.uuid4())
