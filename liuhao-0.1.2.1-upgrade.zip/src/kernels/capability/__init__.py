"""Capability Kernel — Registry + Traceability + Scoping

The Capability Kernel maintains the authoritative registry of all
capabilities across the system, enabling capability lookup, versioning,
traceability, and scope-based access control.

依据 Definition Lock §112: Capability Kernel 必须能够
- Register capabilities with full metadata
- Lookup capabilities by ID + version
- Trace capability → kernel → owner chain
- Check scope permissions (L0-L7)
- Support capability deprecation and migration
"""
from __future__ import annotations
from src.kernels._base import KernelLifecycle, KernelStateError

from dataclasses import dataclass, field
from datetime import datetime
from src._time import utc_now
from enum import Enum
from typing import Any, Dict, List, Optional, Set

from src.kernels._crosscutting import kernel_action


class CapabilityScope(str, Enum):
    """Capability permission scope L0-L7."""
    L0 = "L0"  # Human only
    L1 = "L1"  # Supervised
    L2 = "L2"  # Assisted
    L3 = "L3"  # Collaborative
    L4 = "L4"  # Semi-autonomous
    L5 = "L5"  # Mostly autonomous
    L6 = "L6"  # Highly autonomous
    L7 = "L7"  # Full autonomy


class CapabilityStatus(str, Enum):
    """Capability lifecycle status."""
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    RETIRED = "retired"
    EXPERIMENTAL = "experimental"


@dataclass
class CapabilityEntry:
    """Single capability registry entry."""
    id: str
    version: str
    namespace: str
    name: str
    description: str
    scope: CapabilityScope
    owner: str  # kernel or component that owns this capability
    status: CapabilityStatus = CapabilityStatus.ACTIVE
    tags: Set[str] = field(default_factory=set)
    dependencies: List[str] = field(default_factory=list)  # other capability IDs
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=utc_now)
    updated_at: datetime = field(default_factory=utc_now)
    deprecated_at: Optional[datetime] = None
    traceability_chain: List[str] = field(default_factory=list)  # [kernel, capability, owner, ...]

    def __post_init__(self):
        if not self.traceability_chain:
            self.traceability_chain = [self.owner, self.id, f"v{self.version}"]

    @property
    def full_id(self) -> str:
        return f"{self.namespace}.{self.id}@v{self.version}"

    def is_compatible_with(self, other: "CapabilityEntry") -> bool:
        """Check if this capability is compatible with another (same major version)."""
        try:
            self_major = int(self.version.split(".")[0])
            other_major = int(other.version.split(".")[0])
            return self_major == other_major
        except (ValueError, IndexError):
            return False


@dataclass
class CapabilityQuery:
    """Query parameters for capability lookup."""
    id: Optional[str] = None
    namespace: Optional[str] = None
    version: Optional[str] = None
    scope: Optional[CapabilityScope] = None
    status: Optional[CapabilityStatus] = None
    owner: Optional[str] = None
    tags: Optional[Set[str]] = None


@dataclass
class ScopeCheckResult:
    """Result of a scope permission check."""
    allowed: bool
    requested_scope: CapabilityScope
    capability_scope: CapabilityScope
    reason: str
    traceability: List[str]


class CapabilityRegistry:
    """Authoritative capability registry with traceability."""
    lifecycle: KernelLifecycle = KernelLifecycle.UNINITIALIZED

    def __init__(self):
        self._capabilities: Dict[str, CapabilityEntry] = {}  # key: full_id
        self._by_namespace: Dict[str, Set[str]] = {}  # namespace -> set of full_ids
        self._by_owner: Dict[str, Set[str]] = {}  # owner -> set of full_ids
        self._by_tag: Dict[str, Set[str]] = {}  # tag -> set of full_ids
        self._deprecated_aliases: Dict[str, str] = {}  # old_full_id -> new_full_id

    @kernel_action("capability.register")
    def register(self, capability: CapabilityEntry) -> bool:
        """Register a new capability. Returns True if new, False if updated."""
        key = capability.full_id
        is_new = key not in self._capabilities

        # Update indexes
        self._capabilities[key] = capability

        # Namespace index
        if capability.namespace not in self._by_namespace:
            self._by_namespace[capability.namespace] = set()
        self._by_namespace[capability.namespace].add(key)

        # Owner index
        if capability.owner not in self._by_owner:
            self._by_owner[capability.owner] = set()
        self._by_owner[capability.owner].add(key)

        # Tag indexes
        for tag in capability.tags:
            if tag not in self._by_tag:
                self._by_tag[tag] = set()
            self._by_tag[tag].add(key)

        capability.updated_at = utc_now()
        return is_new

    def lookup(
        self,
        id: str,
        namespace: str = "core",
        version: Optional[str] = None
    ) -> Optional[CapabilityEntry]:
        """Lookup capability by ID, namespace, and optional version."""
        if version:
            key = f"{namespace}.{id}@v{version}"
            return self._capabilities.get(key)

        # Find latest version if not specified
        candidates = [
            cap for cap in self._capabilities.values()
            if cap.id == id and cap.namespace == namespace and cap.status == CapabilityStatus.ACTIVE
        ]
        if not candidates:
            return None

        # Return highest version
        def version_key(cap: CapabilityEntry):
            try:
                parts = cap.version.split(".")
                return tuple(int(p) for p in parts)
            except (ValueError, IndexError):
                return (0,)

        return max(candidates, key=version_key)

    def query(self, query: CapabilityQuery) -> List[CapabilityEntry]:
        """Query capabilities with flexible filters."""
        results = list(self._capabilities.values())

        if query.id:
            results = [c for c in results if c.id == query.id]
        if query.namespace:
            results = [c for c in results if c.namespace == query.namespace]
        if query.version:
            results = [c for c in results if c.version == query.version]
        if query.scope:
            results = [c for c in results if c.scope == query.scope]
        if query.status:
            results = [c for c in results if c.status == query.status]
        if query.owner:
            results = [c for c in results if c.owner == query.owner]
        if query.tags:
            results = [c for c in results if query.tags.issubset(c.tags)]

        return results

    def check_scope(
        self,
        capability_id: str,
        requested_scope: CapabilityScope,
        namespace: str = "core",
        version: Optional[str] = None
    ) -> ScopeCheckResult:
        """Check if requested scope is allowed for capability."""
        cap = self.lookup(capability_id, namespace, version)
        if not cap:
            return ScopeCheckResult(
                allowed=False,
                requested_scope=requested_scope,
                capability_scope=CapabilityScope.L0,
                reason=f"Capability not found: {namespace}.{capability_id}",
                traceability=[]
            )

        # Scope hierarchy: L7 > L6 > ... > L0
        scope_order = {s: i for i, s in enumerate(CapabilityScope)}
        allowed = scope_order[requested_scope] <= scope_order[cap.scope]

        return ScopeCheckResult(
            allowed=allowed,
            requested_scope=requested_scope,
            capability_scope=cap.scope,
            reason="Scope permitted" if allowed else f"Requested {requested_scope} exceeds capability {cap.scope}",
            traceability=cap.traceability_chain
        )

    def get_traceability(self, capability_id: str, namespace: str = "core") -> List[str]:
        """Get full traceability chain for a capability."""
        cap = self.lookup(capability_id, namespace)
        if not cap:
            return []
        return cap.traceability_chain

    @kernel_action("capability.deprecate")
    def deprecate(
        self,
        capability_id: str,
        namespace: str = "core",
        replacement_id: Optional[str] = None,
        replacement_namespace: Optional[str] = None
    ) -> bool:
        """Deprecate a capability, optionally with replacement."""
        cap = self.lookup(capability_id, namespace)
        if not cap:
            return False

        cap.status = CapabilityStatus.DEPRECATED
        cap.deprecated_at = utc_now()
        cap.updated_at = utc_now()

        if replacement_id and replacement_namespace:
            old_key = cap.full_id
            new_key = f"{replacement_namespace}.{replacement_id}@v{self.lookup(replacement_id, replacement_namespace).version if self.lookup(replacement_id, replacement_namespace) else '1.0.0'}"
            self._deprecated_aliases[old_key] = new_key

        return True

    @kernel_action("capability.retire")
    def retire(self, capability_id: str, namespace: str = "core") -> bool:
        """Retire a capability (no longer usable)."""
        cap = self.lookup(capability_id, namespace)
        if not cap:
            return False
        cap.status = CapabilityStatus.RETIRED
        cap.updated_at = utc_now()
        return True

    def get_all_by_owner(self, owner: str) -> List[CapabilityEntry]:
        """Get all capabilities owned by a kernel/component."""
        keys = self._by_owner.get(owner, set())
        return [self._capabilities[k] for k in keys if k in self._capabilities]

    def get_all_by_namespace(self, namespace: str) -> List[CapabilityEntry]:
        """Get all capabilities in a namespace."""
        keys = self._by_namespace.get(namespace, set())
        return [self._capabilities[k] for k in keys if k in self._capabilities]

    def get_all_by_tag(self, tag: str) -> List[CapabilityEntry]:
        """Get all capabilities with a specific tag."""
        keys = self._by_tag.get(tag, set())
        return [self._capabilities[k] for k in keys if k in self._capabilities]

    def resolve_deprecated(self, full_id: str) -> Optional[str]:
        """Resolve deprecated capability to its replacement."""
        return self._deprecated_aliases.get(full_id)

    def count(self) -> int:
        return len(self._capabilities)

    def count_active(self) -> int:
        return sum(1 for c in self._capabilities.values() if c.status == CapabilityStatus.ACTIVE)

    def initialize(self) -> None:
        self.lifecycle = KernelLifecycle.READY

    def shutdown(self) -> None:
        self.lifecycle = KernelLifecycle.STOPPED

    def pause(self) -> None:
        if self.lifecycle not in (KernelLifecycle.READY, KernelLifecycle.UNINITIALIZED):
            raise KernelStateError(f"cannot pause from {self.lifecycle}")
        self.lifecycle = KernelLifecycle.PAUSED

    def resume(self) -> None:
        if self.lifecycle is not KernelLifecycle.PAUSED:
            raise KernelStateError(f"cannot resume from {self.lifecycle}")
        self.lifecycle = KernelLifecycle.READY


# Global registry instance
_global_registry: Optional[CapabilityRegistry] = None


def get_capability_registry() -> CapabilityRegistry:
    """Get or create the global capability registry.

    初始化失败时**不能**把半成品注册表留在全局：``register`` 带审计
    （``@kernel_action``），磁盘满 / 审计库不可写时会 fail-closed 抛出。若这时
    已经把空/半满的注册表挂到 ``_global_registry``，之后每个调用都会拿着它
    查出 "Capability not found"，连磁盘恢复后也要重启进程才能用（实测：磁盘
    满时启动网关，恢复空间后目标执行仍报 ``kernel.execution_pipeline`` 不存在）。
    因此只有完整注册成功才发布到全局，失败原样抛出、下次调用重新尝试。
    """
    global _global_registry
    if _global_registry is None:
        registry = CapabilityRegistry()
        # Register built-in kernel capabilities
        _register_builtin_capabilities(registry)
        registry.initialize()  # 存在即 READY：构造完成即视为就绪
        _global_registry = registry
    return _global_registry


def _register_builtin_capabilities(registry: CapabilityRegistry) -> None:
    """Register the 12 kernel built-in capabilities."""
    builtins = [
        # Context Kernel
        CapabilityEntry(
            id="context_compression",
            version="1.0.0",
            namespace="kernel",
            name="Context Compression",
            description="12 inputs → compression → model-ready context",
            scope=CapabilityScope.L3,
            owner="context_kernel",
            tags={"kernel", "context", "compression"},
        ),
        # Capability Kernel (self)
        CapabilityEntry(
            id="capability_registry",
            version="1.0.0",
            namespace="kernel",
            name="Capability Registry",
            description="Registry + traceability + scoping",
            scope=CapabilityScope.L3,
            owner="capability_kernel",
            tags={"kernel", "registry", "traceability"},
        ),
        # Event Kernel
        CapabilityEntry(
            id="event_bus",
            version="1.0.0",
            namespace="kernel",
            name="Event Bus",
            description="Unified event bus + correlation IDs",
            scope=CapabilityScope.L2,
            owner="event_kernel",
            tags={"kernel", "event", "bus", "correlation"},
        ),
        # Execution Kernel
        CapabilityEntry(
            id="execution_pipeline",
            version="1.0.0",
            namespace="kernel",
            name="Execution Pipeline",
            description="Goal→Task→Plan→Action→Verify",
            scope=CapabilityScope.L3,
            owner="execution_kernel",
            tags={"kernel", "execution", "pipeline"},
        ),
        # Resource Kernel
        CapabilityEntry(
            id="resource_quotas",
            version="1.0.0",
            namespace="kernel",
            name="Resource Quotas",
            description="CPU/Mem/Storage/Token/Time/$ Quotas",
            scope=CapabilityScope.L3,
            owner="resource_kernel",
            tags={"kernel", "resource", "quotas"},
        ),
        # Policy Kernel
        CapabilityEntry(
            id="policy_engine",
            version="1.0.0",
            namespace="kernel",
            name="Policy Engine",
            description="Permission boundaries + policy engine",
            scope=CapabilityScope.L4,
            owner="policy_kernel",
            tags={"kernel", "policy", "permissions"},
        ),
        # Network Kernel
        CapabilityEntry(
            id="network_bus",
            version="1.0.0",
            namespace="kernel",
            name="Network Bus",
            description="Protocol adapters + communication bus",
            scope=CapabilityScope.L3,
            owner="network_kernel",
            tags={"kernel", "network", "protocol"},
        ),
        # Trust Kernel
        CapabilityEntry(
            id="trust_chain",
            version="1.0.0",
            namespace="kernel",
            name="Trust Chain",
            description="Trust scores + chain + revocation",
            scope=CapabilityScope.L4,
            owner="trust_kernel",
            tags={"kernel", "trust", "chain"},
        ),
        # Evaluation Kernel
        CapabilityEntry(
            id="evaluation_engine",
            version="1.0.0",
            namespace="kernel",
            name="Evaluation Engine",
            description="Outcome evaluation + feedback loop",
            scope=CapabilityScope.L3,
            owner="evaluation_kernel",
            tags={"kernel", "evaluation", "feedback"},
        ),
        # Identity Kernel
        CapabilityEntry(
            id="agent_identity",
            version="1.0.0",
            namespace="kernel",
            name="Agent Identity",
            description="Agent identity + permissions",
            scope=CapabilityScope.L4,
            owner="identity_kernel",
            tags={"kernel", "identity", "permissions"},
        ),
        # Memory Kernel
        CapabilityEntry(
            id="multi_tier_memory",
            version="1.0.0",
            namespace="kernel",
            name="Multi-Tier Memory",
            description="Multi-tier memory + scoping",
            scope=CapabilityScope.L3,
            owner="memory_kernel",
            tags={"kernel", "memory", "multi-tier"},
        ),
        # Security Kernel
        CapabilityEntry(
            id="security_enforcement",
            version="1.0.0",
            namespace="kernel",
            name="Security Enforcement",
            description="RBAC + ABAC + Audit",
            scope=CapabilityScope.L5,
            owner="security_kernel",
            tags={"kernel", "security", "rbac", "abac"},
        ),
        # Local Real-Execution Capability (WS1)
        # Declared as a real system capability. Whether it *executes* depends on
        # whether a local tool (RestrictedPython-backed) is wired into the
        # ToolRegistry. With no tool, execution fails loudly with
        # "no active tool for capability" instead of silently simulating.
        CapabilityEntry(
            id="python_compute",
            version="1.0.0",
            namespace="kernel",
            name="Local Python Compute",
            description=(
                "Execute pure-compute Python locally via the RestrictedPython backend. "
                "Capability isolation only (import/open/eval blocked at compile time; CPU "
                "timeout via child process). Executable only when a local tool is wired; "
                "otherwise fails with 'no active tool for capability'."
            ),
            scope=CapabilityScope.L3,
            owner="ai_local_tools",
            tags={"kernel", "execution", "local", "compute", "restricted-python"},
        ),
        # Local Real-Execution Capability — file write inside the workspace (WS1b)
        # Same contract as python_compute: declared as a real system capability,
        # but it ONLY executes when a local tool is wired into the ToolRegistry.
        # With no tool, execution fails loudly with "no active tool for capability"
        # instead of silently simulating. The tool itself is path-contained:
        # writes are resolved through ``resolve_in_workspace`` and anything
        # outside the workspace root is refused (fail-closed).
        CapabilityEntry(
            id="file_write",
            version="1.0.0",
            namespace="kernel",
            name="Local Workspace File Write",
            description=(
                "Write a file inside the LIUHAO workspace. Path containment is "
                "enforced (realpath must stay inside the workspace root; traversal "
                "is refused). Executable only when a local tool is wired; otherwise "
                "fails with 'no active tool for capability'."
            ),
            scope=CapabilityScope.L3,
            owner="ai_local_tools",
            tags={"kernel", "execution", "local", "filesystem", "workspace"},
        ),
        # Local Real-Execution Capability — constrained static preview (WS1c)
        # The static root is fixed at tool-registration time (the task workspace);
        # no command is executed and the server binds 127.0.0.1 only. Declared
        # here so the execution kernel's scope check can resolve it; it still only
        # runs when a preview tool is wired into the ToolRegistry.
        CapabilityEntry(
            id="preview_start",
            version="1.0.0",
            namespace="kernel",
            name="Workspace Static Preview (start)",
            description=(
                "Start a built-in static file server rooted at the task workspace "
                "(127.0.0.1, auto free port). Paths outside the workspace, "
                "cross-drive paths and any '..' segment are refused; no shell or "
                "arbitrary command is executed. Returns a handle + URL and a real "
                "HTTP self-check."
            ),
            scope=CapabilityScope.L3,
            owner="ai_local_tools",
            tags={"kernel", "execution", "local", "preview", "static-server"},
        ),
        CapabilityEntry(
            id="preview_stop",
            version="1.0.0",
            namespace="kernel",
            name="Workspace Static Preview (stop)",
            description=(
                "Stop a preview started by preview_start (by handle, or all "
                "previews owned by the process). Previews are also auto-stopped "
                "when the task ends/fails and on idle timeout."
            ),
            scope=CapabilityScope.L3,
            owner="ai_local_tools",
            tags={"kernel", "execution", "local", "preview", "cleanup"},
        ),
    ]

    for cap in builtins:
        registry.register(cap)


# Convenience functions
def register_capability(
    id: str,
    version: str,
    namespace: str,
    name: str,
    description: str,
    scope: CapabilityScope,
    owner: str,
    tags: Optional[Set[str]] = None,
    dependencies: Optional[List[str]] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> CapabilityEntry:
    """Register a capability and return the entry."""
    cap = CapabilityEntry(
        id=id,
        version=version,
        namespace=namespace,
        name=name,
        description=description,
        scope=scope,
        owner=owner,
        tags=tags or set(),
        dependencies=dependencies or [],
        metadata=metadata or {},
    )
    get_capability_registry().register(cap)
    return cap


def lookup_capability(id: str, namespace: str = "kernel", version: Optional[str] = None) -> Optional[CapabilityEntry]:
    """Lookup a capability.

    The convenience default is ``"kernel"`` (not ``"core"``) because the
    12 built-in kernel capabilities are registered under the ``kernel``
    namespace. Using ``"core"`` as the default made builtins
    undiscoverable through the default lookup (Sprint 2 defect).
    """
    return get_capability_registry().lookup(id, namespace, version)


def check_capability_scope(
    capability_id: str,
    requested_scope: CapabilityScope,
    namespace: str = "kernel",
    version: Optional[str] = None
) -> ScopeCheckResult:
    """Check if scope is permitted for capability."""
    return get_capability_registry().check_scope(capability_id, requested_scope, namespace, version)


def get_capability_traceability(capability_id: str, namespace: str = "kernel") -> List[str]:
    """Get capability traceability chain."""
    return get_capability_registry().get_traceability(capability_id, namespace)
