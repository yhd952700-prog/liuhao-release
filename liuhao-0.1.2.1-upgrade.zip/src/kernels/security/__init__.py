"""Security Kernel — RBAC+ABAC+Audit enforcement

The Security Kernel provides comprehensive access control with RBAC and ABAC
policies, full audit logging.

依据 Definition Lock §112: Security Kernel 必须能够
- RBAC role-based access control with role hierarchies
- ABAC attribute-based access control with condition evaluation
- Complete audit trail for all access decisions
- Human sovereignty override capability
- Scope enforcement L0-L7

NOTE (2026-10-02 honesty correction): this kernel does NOT integrate Vault
Transit. The earlier "Vault" claims were removed — `VAULT_AVAILABLE` had zero
consumers and the old stub silently returned empty reads. The real Vault client
lives in src/security/vault_client.py and src/integrations/vault/ and is not
wired here. See KERNEL-PRODUCT-CAPABILITY.md §10.
"""
from __future__ import annotations
from src.kernels._base import KernelLifecycle, KernelStateError, is_servable

import importlib.util
import logging
import threading
from datetime import datetime

from src._time import utc_now
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple
import uuid

from src.kernels._crosscutting import kernel_action, mark_action_denied
from ._permission_map import get_mapping

_log = logging.getLogger(__name__)

# Vault availability probe.
#
# 2026-09-13 实测修正：此处原本是
#     try: from vault_connect import VaultClient, secret_id
#     except ImportError: <定义同名桩类>
# 而 `vault_connect` 在 PyPI 上**根本不存在**（`pip index versions vault_connect`
# 返回 "No matching distribution found"），也从未出现在 pyproject /
# requirements.txt / oss-registry.yaml 的任何依赖清单里。后果有两条，
# 都是这个项目反复吃过的亏：
#   1. `VAULT_AVAILABLE` 恒为 False —— 这不是"可选依赖没装"，而是一条
#      **永远走不到的分支**（幻影依赖）；
#   2. 那个桩类的 `read()` 返回 `{"data": None}`、`write()/delete()` 静默丢弃
#      —— 即"读密钥"会**静默返回空**而不报错（silent no-op）。
# 实测该桩类与 `secret_id` 在本模块内外**均无任何消费方**（全仓 grep 零命中，
# `VAULT_AVAILABLE` 也无人读取），故整体移除，不再保留会撒谎的桩。
#
# 真实的 Vault 实现不在本内核，而在 `src/security/vault_client.py`
# （hvac + AppRole 认证）与 `src/integrations/vault/`（hvac + 单例 + secret_manager）。
# 本内核只如实报告**客户端库是否可用**；内核层不得反向依赖那两层。
#
# 用 find_spec 而不是 `import hvac`：hvac 会连带导入 requests 等约 2.0s 的
# 依赖树（实测），而这里只需要"装没装"这个布尔值。find_spec 不执行模块体，
# 语义与 `import hvac` 成功/失败完全一致（测试也按 find_spec 断言）。
VAULT_AVAILABLE = importlib.util.find_spec("hvac") is not None


# ---------------------------------------------------------------------------
# Scope governance (S4 design ruling)
#
# The security kernel only honours the eight MemoryScope tiers L0-L7. Any
# other value (None, "", "global", "L9", ...) is rejected as an invalid
# scope and can never produce an ALLOW decision.
# ---------------------------------------------------------------------------
_VALID_SCOPES = frozenset(f"L{i}" for i in range(8))
_SCOPE_LEVEL = {s: i for i, s in enumerate(_VALID_SCOPES)}


def _is_valid_scope(scope: Any) -> bool:
    """True iff *scope* is a recognised MemoryScope tier string (L0-L7)."""
    return isinstance(scope, str) and scope in _VALID_SCOPES


# ---------------------------------------------------------------------------
# Protected security attributes (S3 design ruling)
#
# These attributes drive authorization decisions. Their STORED values are
# authoritative: a request may never override them, even to fill a "missing"
# key. Escalating clearance / trust / role / permission / scope from a
# caller-supplied value is exactly the privilege-escalation gap S3 closes.
# ---------------------------------------------------------------------------
_PROTECTED_SECURITY_ATTRS = frozenset({
    "trust_score", "trust", "clearance",
    "role", "roles", "permission", "permissions",
    "scope", "identity", "identity_id", "principal",
})


class AccessDecision(str, Enum):
    """Access decision outcomes."""
    ALLOW = "allow"
    DENY = "deny"
    CONDITIONAL = "conditional"
    DEFER = "defer"
    ESCALATE = "escalate"


# Normalizes audit result strings to the canonical counter keys used by
# SecurityEngine.stats(): check entries record "allowed"/"denied" while
# decision entries record "allow"/"deny".
_RESULT_KEY_ALIASES = {
    "allowed": "allow",
    "denied": "deny",
}


class RBACRole(str, Enum):
    """Predefined RBAC roles."""
    ADMIN = "admin"
    OPERATOR = "operator"
    VIEWER = "viewer"
    AUDITOR = "auditor"
    SERVICE = "service"
    HUMAN_SOVEREIGNTY = "human_sovereignty"


class ABATCondition(str, Enum):
    """ABAC condition types."""
    GREATER_THAN = "gt"
    LESS_THAN = "lt"
    EQUALS = "eq"
    NOT_EQUALS = "ne"
    IN_SET = "in_set"
    NOT_IN_SET = "not_in_set"


@dataclass
class SecurityPrincipal:
    """Principal entity for access control."""
    id: str
    identity_id: str
    roles: Set[RBACRole] = field(default_factory=set)
    attributes: Dict[str, Any] = field(default_factory=dict)
    scope: str = "L1"
    trust_score: float = 0.5
    status: str = "active"
    created_at: datetime = field(default_factory=utc_now)
    last_validated: Optional[datetime] = None


@dataclass
class RBACRule:
    """RBAC access rule."""
    id: str
    role: RBACRole
    permission: str
    enabled: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ABACRule:
    """ABAC access rule with attribute conditions."""
    id: str
    permission: str
    condition_attribute: str
    condition_operator: ABATCondition
    condition_value: Any
    enabled: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AuditLogEntry:
    """Audit log entry for security events."""
    id: str
    principal_id: str
    operation: str
    permission: str
    scope: str
    result: str
    reason: str
    timestamp: datetime
    correlation_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])


class SecurityEngine:
    """Core security engine with RBAC, ABAC, and audit capabilities."""
    lifecycle: KernelLifecycle = KernelLifecycle.UNINITIALIZED

    def __init__(self):
        self._rbac_rules: Dict[str, RBACRule] = {}
        self._abac_rules: Dict[str, ABACRule] = {}
        self._principal_roles: Dict[str, Set[RBACRole]] = {}
        self._principal_attrs: Dict[str, Dict[str, Any]] = {}
        # Per-principal authorized scope ceiling (S4). Absent => no ceiling.
        self._principal_scopes: Dict[str, str] = {}
        self._audit_log: List[AuditLogEntry] = []
        self._lock = threading.RLock()

        self._seed_default_rules()

    def _seed_default_rules(self) -> None:
        """No default RBAC rules are seeded; this hook is intentionally empty.

        **2026-09-15 (boss-approved full cut): no colon permissions are seeded
        by default.** Measured with ``discover_permission_literals``: only
        ``research:read`` has a production call site, and it was never seeded
        (fail-closed by design); the other 12 had zero production consumers, so
        shipping them as default grants was dead configuration that only
        widened the unused authority surface.

        Callers that need colon rules must register them explicitly -- the RBAC
        mechanism itself is unchanged. The registry
        (``_permission_map.PERMISSION_MAP``) keeps ``research:read`` for
        visibility. See ``docs/ACCESS-CONTROL-CONVERGENCE-DESIGN.md``.
        """
        # Intentionally empty.
        return

    def set_principal_roles(self, principal_id: str, roles: Set[RBACRole]) -> None:
        """Set RBAC roles for a principal."""
        with self._lock:
            self._principal_roles[principal_id] = roles

    def set_principal_attributes(self, principal_id: str, attributes: Dict[str, Any]) -> None:
        """Set ABAC attributes for a principal."""
        with self._lock:
            self._principal_attrs[principal_id] = attributes

    def set_principal_scope(self, principal_id: str, scope: str) -> None:
        """Record the maximum scope a principal is authorized to act at (S4).

        *scope* must be a valid tier (L0-L7); otherwise it is rejected so a
        malformed ceiling can never widen authority. The stored scope forms
        the ceiling used by ``_enforce_principal_scope``.
        """
        with self._lock:
            if not _is_valid_scope(scope):
                return
            self._principal_scopes[principal_id] = scope

    def _enforce_principal_scope(self, principal_id: str, scope: str) -> Optional[AccessDecision]:
        """Enforce the principal's authorized scope ceiling (S4).

        ``SecurityEngine.set_principal_scope`` records the maximum scope a
        principal may act at. A request is permitted only when the request
        scope level is <= the principal's authorized level -- equivalently,
        the principal's authorized scope is an *ancestor* (superset) of the
        requested scope in the authorization lattice. When no ceiling is
        recorded the check is a no-op (backward compatible).
        """
        p_scope = self._principal_scopes.get(principal_id)
        if p_scope is None:
            return None
        if _SCOPE_LEVEL[scope] > _SCOPE_LEVEL[p_scope]:
            return AccessDecision.DENY
        return None

    def _audit_rbac_check(
        self,
        principal_id: str,
        permission: str,
        scope: str,
        result: str,
        reason: str,
    ) -> None:
        """Append an RBAC audit entry (shared by the reject paths)."""
        audit = AuditLogEntry(
            id=str(uuid.uuid4())[:8],
            principal_id=principal_id,
            operation="rbac_check",
            permission=permission,
            scope=scope,
            result=result,
            reason=reason,
            timestamp=utc_now(),
        )
        self._audit_log.append(audit)

    @kernel_action("security.grant_rbac_role")
    def grant_rbac_role(self, principal_id: str, role: RBACRole, reason: str = "") -> bool:
        """Grant an RBAC role to a principal."""
        with self._lock:
            if principal_id not in self._principal_roles:
                self._principal_roles[principal_id] = set()
            self._principal_roles[principal_id].add(role)

            audit = AuditLogEntry(
                id=str(uuid.uuid4())[:8],
                principal_id=principal_id,
                operation="grant_role",
                permission=f"role:{role.value}",
                scope=principal_id,
                result="allowed",
                reason=reason or f"RBAC role {role.value} granted to principal {principal_id}",
                timestamp=utc_now(),
            )
            self._audit_log.append(audit)
            return True

    @kernel_action("security.revoke_rbac_role")
    def revoke_rbac_role(self, principal_id: str, role: RBACRole, reason: str = "") -> bool:
        """Revoke an RBAC role from a principal."""
        with self._lock:
            if principal_id in self._principal_roles and role in self._principal_roles[principal_id]:
                self._principal_roles[principal_id].discard(role)

                audit = AuditLogEntry(
                    id=str(uuid.uuid4())[:8],
                    principal_id=principal_id,
                    operation="revoke_role",
                    permission=f"role:{role.value}",
                    scope=principal_id,
                    result="allowed",
                    reason=reason or f"RBAC role {role.value} revoked from principal {principal_id}",
                    timestamp=utc_now(),
                )
                self._audit_log.append(audit)
                return True
            mark_action_denied(
                f"revoke_rbac_role rejected: {principal_id!r} does not hold role {role.value}"
            )
            return False

    def check_rbac(self, principal_id: str, permission: str, scope: str = "L1") -> AccessDecision:
        """Check RBAC access for principal + permission.

        Scope participates in the decision (S4): an invalid scope value is
        rejected with DENY, and a request whose scope exceeds the
        principal's authorized ceiling is denied.

        Lifecycle gate: a PAUSED / STOPPED security engine returns DENY (and
        audits it) instead of adjudicating. ``pause()`` used to only flip a
        flag, so a "paused" engine kept granting access. The refusal is a
        *returned DENY*, never a raised exception -- a caller that catches
        broadly would otherwise turn "denied" into an unhandled path whose
        effective direction is fail-OPEN, which is precisely the wrong way
        for this kernel to fail.
        """
        with self._lock:
            if not is_servable(self):
                self._audit_rbac_check(
                    principal_id, permission, scope, "denied",
                    f"RBAC check denied: security engine is "
                    f"{self.lifecycle.value}",
                )
                return AccessDecision.DENY

            if not _is_valid_scope(scope):
                self._audit_rbac_check(principal_id, permission, scope, "denied",
                                       f"RBAC check denied: invalid scope {scope!r}")
                return AccessDecision.DENY

            ceiling_denied = self._enforce_principal_scope(principal_id, scope)
            if ceiling_denied is not None:
                self._audit_rbac_check(
                    principal_id, permission, scope, "denied",
                    f"RBAC check denied: request scope {scope} exceeds principal "
                    f"authorized scope {self._principal_scopes.get(principal_id)!r}",
                )
                return ceiling_denied

            principal_roles = self._principal_roles.get(principal_id, set())
            rule = self._rbac_rules.get(permission)
            if rule and rule.enabled:
                if rule.role in principal_roles:
                    audit = AuditLogEntry(
                        id=str(uuid.uuid4())[:8],
                        principal_id=principal_id,
                        operation="rbac_check",
                        permission=permission,
                        scope=scope,
                        result="allowed",
                        reason=f"RBAC check passed: principal {principal_id} has role {rule.role.value} for {permission}",
                        timestamp=utc_now(),
                    )
                    self._audit_log.append(audit)
                    return AccessDecision.ALLOW

            audit = AuditLogEntry(
                id=str(uuid.uuid4())[:8],
                principal_id=principal_id,
                operation="rbac_check",
                permission=permission,
                scope=scope,
                result="denied",
                reason=f"RBAC check failed: principal {principal_id} lacks role {rule.role.value if rule else 'N/A'} for {permission}",
                timestamp=utc_now(),
            )
            self._audit_log.append(audit)
            return AccessDecision.DENY

    def check_abac(self, principal_id: str, permission: str, scope: str = "L1", attributes: Optional[Dict[str, Any]] = None) -> AccessDecision:
        """Check ABAC access for principal + permission + attributes.

        Scope participates in the decision (S4): an invalid scope value is
        rejected with DENY.

        Attribute merge policy (S3): the principal's STORED attributes are
        the authoritative baseline. Request-supplied ``attributes`` may only
        *fill missing keys*; they can never override an existing stored
        value, and any protected security attribute (see
        ``_PROTECTED_SECURITY_ATTRS``) is always taken from storage even if
        a request attempts to supply it. This closes the privilege-
        escalation gap where a caller fabricated ``clearance`` /
        ``trust_score`` / ``scope`` values.
        """
        with self._lock:
            if not _is_valid_scope(scope):
                audit = AuditLogEntry(
                    id=str(uuid.uuid4())[:8],
                    principal_id=principal_id,
                    operation="abac_check",
                    permission=permission,
                    scope=scope,
                    result="denied",
                    reason=f"ABAC check denied: invalid scope {scope!r}",
                    timestamp=utc_now(),
                )
                self._audit_log.append(audit)
                return AccessDecision.DENY

            stored_attrs = self._principal_attrs.get(principal_id, {})
            principal_attrs = self._merge_attributes(stored_attrs, attributes)

            rule = self._abac_rules.get(permission)
            if rule and rule.enabled:
                attr_value = principal_attrs.get(rule.condition_attribute)

                result = self._eval_condition(attr_value, rule.condition_operator, rule.condition_value)

                if result:
                    audit = AuditLogEntry(
                        id=str(uuid.uuid4())[:8],
                        principal_id=principal_id,
                        operation="abac_check",
                        permission=permission,
                        scope=scope,
                        result="allowed",
                        reason=f"ABAC check passed: {rule.condition_attribute} {rule.condition_operator} {rule.condition_value}",
                        timestamp=utc_now(),
                    )
                    self._audit_log.append(audit)
                    return AccessDecision.ALLOW

            audit = AuditLogEntry(
                id=str(uuid.uuid4())[:8],
                principal_id=principal_id,
                operation="abac_check",
                permission=permission,
                scope=scope,
                result="denied",
                reason=f"ABAC check failed: condition not met for {permission}",
                timestamp=utc_now(),
            )
            self._audit_log.append(audit)
            return AccessDecision.DENY

    def _merge_attributes(
        self,
        stored: Dict[str, Any],
        request: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Merge stored and request attributes under the S3 baseline rule.

        The stored attributes are authoritative. The request may contribute
        values only for keys the principal has not stored; a request value
        for a key that already exists in storage is ignored (stored wins).
        Protected security attributes (``_PROTECTED_SECURITY_ATTRS``) are
        additionally never taken from the request, even for a missing key,
        so a caller cannot inject a fabricated security claim.
        """
        merged: Dict[str, Any] = dict(stored)
        for key, value in (request or {}).items():
            if key in _PROTECTED_SECURITY_ATTRS:
                # Security attribute: storage is authoritative; ignore request.
                continue
            if key not in merged:
                # Request may supply a value only for an absent key.
                merged[key] = value
            # Existing (non-protected) stored value wins -> do nothing.
        return merged

    def _eval_condition(self, actual: Any, operator: ABATCondition, expected: Any) -> bool:
        """Evaluate an ABAC condition.

        A missing attribute (None) never satisfies a comparison
        condition: absent evidence must fail closed, not fall back to
        string comparison of "None".
        """
        if operator == ABATCondition.EQUALS:
            return actual == expected
        elif operator == ABATCondition.NOT_EQUALS:
            return actual != expected
        elif operator == ABATCondition.GREATER_THAN:
            if actual is None or expected is None:
                return False
            try:
                return float(actual) > float(expected)
            except (ValueError, TypeError):
                return str(actual) > str(expected)
        elif operator == ABATCondition.LESS_THAN:
            if actual is None or expected is None:
                return False
            try:
                return float(actual) < float(expected)
            except (ValueError, TypeError):
                return str(actual) < str(expected)
        elif operator == ABATCondition.IN_SET:
            return actual in expected if isinstance(expected, (list, set, tuple)) else actual == expected
        elif operator == ABATCondition.NOT_IN_SET:
            return actual not in expected if isinstance(expected, (list, set, tuple)) else actual != expected
        return False

    @kernel_action("security.set_abac_rule")
    def set_abac_rule(self, permission: str, condition_attribute: str, condition_operator: ABATCondition, condition_value: Any, enabled: bool = True) -> ABACRule:
        """Set an ABAC rule for a permission."""
        with self._lock:
            rule = ABACRule(
                id=str(uuid.uuid4())[:8],
                permission=permission,
                condition_attribute=condition_attribute,
                condition_operator=condition_operator,
                condition_value=condition_value,
                enabled=enabled,
            )
            self._abac_rules[permission] = rule
            return rule

    def check_access(self, principal_id: str, permission: str, scope: str = "L1", attributes: Optional[Dict[str, Any]] = None) -> AccessDecision:
        """Full access check: RBAC + ABAC combination."""
        decision, _, _ = self._evaluate_access(principal_id, permission, scope, attributes)
        return decision

    def _evaluate_access(
        self,
        principal_id: str,
        permission: str,
        scope: str = "L1",
        attributes: Optional[Dict[str, Any]] = None,
    ) -> Tuple[AccessDecision, AccessDecision, Optional[AccessDecision]]:
        """Combined RBAC + ABAC evaluation.

        Returns (final_decision, rbac_result, abac_result_or_None).
        An absent or disabled ABAC rule means "no constraint", not a
        failed constraint: a passing RBAC check then yields a full ALLOW.
        """
        with self._lock:
            rbac_result = self.check_rbac(principal_id, permission, scope)
            abac_rule = self._abac_rules.get(permission)
            abac_applicable = bool(abac_rule and abac_rule.enabled)

            if rbac_result == AccessDecision.ALLOW:
                if not abac_applicable:
                    return AccessDecision.ALLOW, rbac_result, None
                abac_result = self.check_abac(principal_id, permission, scope, attributes)
                if abac_result == AccessDecision.ALLOW:
                    return AccessDecision.ALLOW, rbac_result, abac_result
                # RBAC passed but ABAC failed - conditional
                return AccessDecision.CONDITIONAL, rbac_result, abac_result

            if abac_applicable:
                # RBAC failed, try ABAC alone
                abac_result = self.check_abac(principal_id, permission, scope, attributes)
                if abac_result == AccessDecision.ALLOW:
                    # ABAC passed but RBAC failed - deferred to human
                    return AccessDecision.DEFER, rbac_result, abac_result
                return AccessDecision.DENY, rbac_result, abac_result

            # Both failed
            return AccessDecision.DENY, rbac_result, None

    @kernel_action("security.decide_access")
    def decide_access(self, principal_id: str, permission: str, scope: str = "L1", attributes: Optional[Dict[str, Any]] = None, human_override: bool = False) -> Dict[str, Any]:
        """Full access decision with reasoning.

        Definition Lock section 112 human sovereignty override: when
        ``human_override`` is True **and** ``principal_id`` resolves to a
        verified, ACTIVE human identity, a non-ALLOW decision is overridden
        to ALLOW and the override is recorded in the audit trail.

        SEC-5: the override is *not* a bare boolean escape hatch. An earlier
        revision applied it on the flag alone, so **any** caller could obtain
        ALLOW for **any** permission by passing ``human_override=True`` --
        a privilege-escalation / fail-open hole. The same defect class was
        already closed in the Policy Kernel (C-7: "not a service" is not
        evidence of being human); this is the Security-Kernel twin, so it
        reuses that kernel's predicate (``is_human_identity``) instead of
        inventing a second notion of "human". An unverified principal is
        denied the override and the refusal is audited, not silently ignored.
        """
        with self._lock:
            decision, rbac_result, abac_result = self._evaluate_access(
                principal_id, permission, scope, attributes
            )

            abac_value = abac_result.value if abac_result is not None else "not_applicable"
            parts = [f"rbac={rbac_result.value}", f"abac={abac_value}"]

            if human_override and decision != AccessDecision.ALLOW:
                # SEC-5: gate the override on a verified human principal.
                if self._is_verified_human(principal_id):
                    decision = AccessDecision.ALLOW
                    parts.append("human sovereignty override applied")
                    override_audit = AuditLogEntry(
                        id=str(uuid.uuid4())[:8],
                        principal_id=principal_id,
                        operation="human_sovereignty_override",
                        permission=permission,
                        scope=scope,
                        result="allowed",
                        reason="Human sovereignty override converted a non-allow decision to allow",
                        timestamp=utc_now(),
                    )
                else:
                    parts.append(
                        "human sovereignty override REJECTED: principal is not a "
                        "verified human identity"
                    )
                    override_audit = AuditLogEntry(
                        id=str(uuid.uuid4())[:8],
                        principal_id=principal_id,
                        operation="human_sovereignty_override",
                        permission=permission,
                        scope=scope,
                        result="denied",
                        reason=(
                            "human_override=True ignored: principal_id does not resolve "
                            "to an ACTIVE identity marked kind=human"
                        ),
                        timestamp=utc_now(),
                    )
                self._audit_log.append(override_audit)

            # Convergence observability: an unknown or unseeded permission is
            # *always* denied (``check_rbac`` is fail-closed), and until now
            # that denial was indistinguishable from "checked and refused".
            # Naming the difference is what makes the A/B gap actionable.
            mapping = get_mapping(permission)
            if mapping is None:
                _log.warning(
                    "access decision on UNREGISTERED permission %r (principal=%r): "
                    "no rule can ever match, so this is denied by default. Register "
                    "it in src/kernels/security/_permission_map.py.",
                    permission, principal_id,
                )
            elif not mapping.role:
                _log.warning(
                    "access decision on UNSEEDED permission %r (principal=%r): the "
                    "permission is known but no seed rule grants it, so this is "
                    "denied for everyone.",
                    permission, principal_id,
                )

            result = {
                "decision": decision.value,
                "principal_id": principal_id,
                "permission": permission,
                "scope": scope,
                "rbac_check": rbac_result.value,
                "abac_check": abac_value,
                "reason": "; ".join(parts),
                "human_override": human_override,
                "permission_known": mapping is not None,
                "permission_seeded": bool(mapping and mapping.role),
                "kernel_actions": list(mapping.kernel_actions) if mapping else [],
            }

            # Record decision audit
            audit = AuditLogEntry(
                id=str(uuid.uuid4())[:8],
                principal_id=principal_id,
                operation="access_decision",
                permission=permission,
                scope=scope,
                result=decision.value,
                reason=result["reason"],
                timestamp=utc_now(),
            )
            self._audit_log.append(audit)

            return result

    def _is_verified_human(self, principal_id: str) -> bool:
        """Return True iff ``principal_id`` is a verified, ACTIVE human.

        SEC-5. Mirrors the Policy Kernel's ``_is_verified_human`` contract
        (Policy C-7) rather than defining a second, weaker notion of "human":
        the principal must resolve to a *registered* identity that is ACTIVE
        **and** positively marked ``metadata["kind"] == "human"``.

        Merely *not* being a service is not evidence of being human -- the
        built-in ``system`` identity carries no kind marker and would pass a
        reverse-exclusion test. Identity is imported lazily to keep this
        kernel free of a module-level dependency on the Identity Kernel.
        """
        ref = (principal_id or "").strip()
        if not ref:
            return False
        try:
            from src.kernels.identity import (
                IdentityStatus,
                get_identity_manager,
                is_human_identity,
            )
        except Exception:  # pragma: no cover - defensive
            return False
        try:
            mgr = get_identity_manager()
            ident = mgr.get_identity(ref) or mgr.get_identity_by_principal(ref)
        except Exception:  # pragma: no cover - defensive
            return False
        if ident is None or ident.status != IdentityStatus.ACTIVE:
            return False
        return is_human_identity(ident)

    def audit_trail(self, principal_id: Optional[str] = None, since: Optional[datetime] = None, operation: Optional[str] = None) -> List[AuditLogEntry]:
        """Get security audit trail."""
        with self._lock:
            entries = self._audit_log

            if principal_id:
                entries = [e for e in entries if e.principal_id == principal_id]

            if operation:
                entries = [e for e in entries if e.operation == operation]

            if since:
                entries = [e for e in entries if e.timestamp >= since]

            return sorted(entries, key=lambda e: e.timestamp, reverse=True)

    def stats(self) -> Dict[str, Any]:
        """Get security engine statistics."""
        with self._lock:
            by_operation = {}
            by_result = {"allow": 0, "deny": 0, "conditional": 0, "defer": 0}

            for entry in self._audit_log:
                op = entry.operation
                by_operation[op] = by_operation.get(op, 0) + 1

                # Audit entries record "allowed"/"denied" for checks and
                # decision values ("allow"/"deny"/...) for decisions;
                # normalize so both forms land on the same counter keys.
                normalized = _RESULT_KEY_ALIASES.get(entry.result, entry.result)
                by_result[normalized] = by_result.get(normalized, 0) + 1

            unique_principals = len(set(e.principal_id for e in self._audit_log))

            rbac_count = sum(1 for r in self._rbac_rules.values() if r.enabled)
            abac_count = sum(1 for r in self._abac_rules.values() if r.enabled)

            return {
                "total_audit_entries": len(self._audit_log),
                "by_operation": by_operation,
                "by_result": by_result,
                "unique_principals": unique_principals,
                "rbac_rules_total": len(self._rbac_rules),
                "rbac_rules_enabled": rbac_count,
                "abac_rules_total": len(self._abac_rules),
                "abac_rules_enabled": abac_count,
                "unique_permissions": len(self._rbac_rules) + len(self._abac_rules),
            }

    def initialize(self) -> None:
        self.lifecycle = KernelLifecycle.READY

    def shutdown(self) -> None:
        self.lifecycle = KernelLifecycle.STOPPED

    def pause(self) -> None:
        if self.lifecycle not in (KernelLifecycle.READY, KernelLifecycle.UNINITIALIZED):
            raise KernelStateError(f"cannot pause from {self.lifecycle}")
        self.lifecycle = KernelLifecycle.PAUSED

    def resume(self) -> None:
        if self.lifecycle is not KernelLifecycle.PAUSED:
            raise KernelStateError(f"cannot resume from {self.lifecycle}")
        self.lifecycle = KernelLifecycle.READY


# Global security engine instance
_global_security: Optional[SecurityEngine] = None


def get_security_engine() -> SecurityEngine:
    """Get or create the global security engine instance."""
    global _global_security
    if _global_security is None:
        _global_security = SecurityEngine()
        _global_security.initialize()  # 存在即 READY：构造完成即视为就绪
    return _global_security


def check_rbac(principal_id: str, permission: str, scope: str = "L1") -> AccessDecision:
    """Check RBAC access."""
    return get_security_engine().check_rbac(principal_id, permission, scope)


def check_abac(principal_id: str, permission: str, scope: str = "L1", attributes: Optional[Dict[str, Any]] = None) -> AccessDecision:
    """Check ABAC access."""
    return get_security_engine().check_abac(principal_id, permission, scope, attributes)


def decide_access(principal_id: str, permission: str, scope: str = "L1", attributes: Optional[Dict[str, Any]] = None, human_override: bool = False) -> Dict[str, Any]:
    """Full access decision."""
    return get_security_engine().decide_access(principal_id, permission, scope, attributes, human_override)


def audit_trail(principal_id: Optional[str] = None, since: Optional[datetime] = None, operation: Optional[str] = None) -> List[AuditLogEntry]:
    """Get security audit trail."""
    return get_security_engine().audit_trail(principal_id, since, operation)


def security_stats() -> Dict[str, Any]:
    """Get security engine statistics."""
    return get_security_engine().stats()
