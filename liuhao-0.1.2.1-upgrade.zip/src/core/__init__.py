"""Core runtime lifecycle helpers."""
