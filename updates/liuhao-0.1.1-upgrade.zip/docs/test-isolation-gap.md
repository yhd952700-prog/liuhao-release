# 缺陷说明：只设 `LIUHAO_DATA_DIR` 不足以隔离数据目录

**状态**：已修。业务存储（第一批 17 项）与身份 / 认证 / 审计 / 告警 / 外围存储
（第二批 10 项）都已统一到 `src/common/data_paths`；不能接入的少数项在文末写明理由。
**原始影响**：任何只设置 `LIUHAO_DATA_DIR` 的自动化测试 / 冒烟脚本，都会把会话、
记忆、员工、目标、模型配置与向量数据写进仓库根目录（共享开发目录），污染开发者本机数据。
身份库还会因 `LIUHAO_HUMAN_IDENTITIES_FILE` 缺失而**静默不落盘**，注册接口报
`ACCOUNT_PERSIST_FAILED`（账号树写盘返回 `False`）。

## 根因

每个存储各自读环境变量，而且各认一部分：会话库只认 `CONVERSATION_DB_PATH`，记忆库只认
`MEMORY_DB_PATH`，员工/目标只认 `LIUHAO_WORKSPACE_ROOT`，模型配置只认
`LIUHAO_MODEL_CONFIG_DB`，知识库只认 `LIUHAO_KNOWLEDGE_DB`。**没有任何一处回落到
`LIUHAO_DATA_DIR`**，所以"一套数据目录"被拆成好几处；审计/隔离脚本以为已经干净，
实际仍在写共享开发目录。

## 修法：单一解析入口

新增 [src/common/data_paths.py](../src/common/data_paths.py) 的 `resolve_store_path(filename, legacy_default, env_var=None, workspace=False)`，
优先级固定为：

1. 单存储显式环境变量（`env_var`，如 `CONVERSATION_DB_PATH`）；
2. `LIUHAO_WORKSPACE_ROOT`（只有 `workspace=True` 的工作区类存储才走这一级）；
3. `LIUHAO_DATA_DIR`；
4. 各存储的历史默认值（**不设任何变量时源码模式位置不变**，安装版行为不变）。

解析在**调用时**求值（`_default_db_path()`），避免"导入后才设环境变量"失效。
新增需要落盘的存储必须经过这个入口，不要再自己拼路径、自己读这些变量。

### 已接入的存储（全部经统一入口）

| # | 存储 | 接入点 | 文件名 | 类别 | 单项覆盖变量 |
| --- | --- | --- | --- | --- | --- |
| 1 | 对话历史 | [conversation_store.py](../src/ai/conversation_store.py) | `conversation_store.db` | 数据根 | `CONVERSATION_DB_PATH` |
| 2 | 记忆内核 | [store.py](../src/kernels/memory/store.py) | `memory_store.db` | 数据根 | `MEMORY_DB_PATH` |
| 3 | 个人画像 | [personal_context.py](../src/ai/personal_context.py) | `personal_context.db` | 数据根 | `PERSONAL_CONTEXT_DB_PATH` |
| 4 | 模型配置 DB | [model_config.py](../src/ai/model_config.py) | `model_registry.sqlite3` | 数据根 | `LIUHAO_MODEL_CONFIG_DB` |
| 5 | 模型配置密钥 | [model_config.py](../src/ai/model_config.py) | `model_config.key` | 数据根 | `LIUHAO_MODEL_CONFIG_KEY_FILE` |
| 6 | 知识库向量 | [vector_store.py](../src/knowledge/vector_store.py) | `knowledge_vectors.sqlite3` | 数据根 | `LIUHAO_KNOWLEDGE_DB` |
| 7 | 用量账本 | [account_usage.py](../src/gateway/account_usage.py) | `account_usage.sqlite3` | 工作区 | `LIUHAO_ACCOUNT_USAGE_DB` |
| 8 | 账号记忆 | [account_memory.py](../src/gateway/account_memory.py) | `account_memory.sqlite3` | 工作区 | `LIUHAO_ACCOUNT_MEMORY_DB` |
| 9 | 员工名册 | [employee_store.py](../src/ai/employee_store.py) | `liuhao_employees.json` | 工作区 | —（`LIUHAO_WORKSPACE_ROOT`） |
| 10 | 目标状态 | [ai_management.py](../src/gateway/ai_management.py) | `liuhao_goals.json` | 工作区 | — |
| 11 | planner state | [goal_task_graph.py](../src/ai/goal_task_graph.py) | `planner_state.json` | 工作区 | — |
| 12 | 项目库 | [projects.py](../src/gateway/projects.py) | `liuhao_projects.json` | 工作区 | — |
| 13 | 执行 journal | [ai_management.py](../src/gateway/ai_management.py) | `liuhao_execution.journal` | 工作区 | — |
| 14 | 产物索引 | [index.py](../src/artifacts/index.py) | `liuhao_artifacts.db` | 工作区 | — |
| 15 | 插件索引 | [kernels/plugin/__init__.py](../src/kernels/plugin/__init__.py) | `plugins/registry_index.json` | 工作区 | — |
| 16 | 插件注册表 | [plugins/registry.py](../src/plugins/registry.py) | `plugins/registry.json` | 工作区 | — |
| 17 | 启动器日志 | [start_liuhao.py](../scripts/start_liuhao.py) | `logs/` | 数据根 | `LIUHAO_LOG_DIR` |

第 15、16 项是同一模式的"隐性"成员：旧实现分别用 cwd 相对的 `"./plugins"` 和
`<repo>/data/plugins/`，运行时把未跟踪的 `registry_index.json`
`registry_index.retired.json` `registry.json` 写进源码目录，同样不受
`LIUHAO_DATA_DIR` 约束。

### 第二批：身份 / 认证 / 审计 / 告警 / 外围（本轮补齐）

| # | 存储 | 接入点 | 数据根内位置 | 单项覆盖变量 | 无数据根时 |
| --- | --- | --- | --- | --- | --- |
| 18 | 身份 + 账号树（JSON 后端） | [identity/_persistence.py](../src/kernels/identity/_persistence.py) | `config/human_identities.json` | `LIUHAO_HUMAN_IDENTITIES_FILE` | 保持 `""`：**不落盘**（fail-closed） |
| 19 | 认证口令库 | [gateway/auth.py](../src/gateway/auth.py) | `auth_secrets.json` | `LIUHAO_AUTH_SECRETS_FILE` | 历史默认 `config/auth_secrets.json` |
| 20 | JWT 吊销库 | [security/jwt_handler.py](../src/security/jwt_handler.py) | `liuhao_jwt_revocation.db` | `LIUHAO_JWT_REVOCATION_DB` | 仓库根 `.liuhao_jwt_revocation.db` |
| 21 | 审计证据库 | [kernels/audit/__init__.py](../src/kernels/audit/__init__.py) | `audit_store.db` | `AUDIT_DB_PATH` | 无数据根且无变量：仍拒绝（保护冰封的 HC-01 证据库） |
| 22 | 告警存储 | [observability/alerts/store.py](../src/observability/alerts/store.py) | `observability/alerts.json` | `LIUHAO_ALERTS_STORE_PATH` | 历史默认 `data/alerts.json` |
| 23 | 账号设置 | [gateway/account_settings.py](../src/gateway/account_settings.py) | `account_settings.json` | `LIUHAO_ACCOUNT_SETTINGS_FILE` | `data/account_settings.json` |
| 24 | 模型注册表元数据 | [models/registry.py](../src/models/registry.py) | `model_registry.json` | `LIUHAO_MODEL_REGISTRY_FILE` | `data/model_registry.json` |
| 25 | 联网偏好 | [ai/web_research.py](../src/ai/web_research.py) | `privacy_settings.json` | `LIUHAO_PRIVACY_SETTINGS_FILE` | `data/privacy_settings.json` |
| 26 | 离线情报库 | [intel/store.py](../src/intel/store.py) | `intel/osi_intel.db` | `OSI_DB_PATH` | `data/intel/osi_intel.db` |
| 27 | ORM 主库 | [integrations/orm_models.py](../src/integrations/orm_models.py) | `liuhao_ai_os.db` | `DATABASE_URL` | `sqlite:///./liuhao_ai_os.db` |

两个刻意保留的语义：

- **第 18 项**只有显式设置 `LIUHAO_DATA_DIR` 才给出路径。没有数据根时仍返回 `""`，
  即"未配置就不持久化"，绝不悄悄写进 `%LOCALAPPDATA%` 或仓库根。这正是此前
  `TestCrossOwnerEmployees` 变红的根因修复：conftest 清空了单项变量但设了数据根，
  账号树现在落进数据根，不再返回 `False`。
- **第 21 项**的 `AUDIT_DB_PATH` 是冻结证据库的保护开关。只有"显式变量"或"数据根"
  之一存在时才允许打开新库，两者都没有时维持原有拒绝行为。
- 第 27 项不能直接套 `resolve_store_path`：`DATABASE_URL` 是 SQLAlchemy URL 而不是
  文件路径，因此单独实现 `default_database_url()`，并补 `_ensure_sqlite_parent()`
  （SQLite 不会自动建父目录）。

## 实测：改前 / 改后「仓库根目录污染」

探针（仓库外临时脚本）流程：只设 `LIUHAO_DATA_DIR`（并清掉 `LIUHAO_WORKSPACE_ROOT`
及各单项覆盖变量，避免掩盖缺陷）→ `TestClient(get_app())` 真实 lifespan →
注册根账号 → 登录 → 建 mock 模型 → `POST /v1/chat` 发一条消息 → `POST /v1/employees`
建一个员工 → `POST /v1/goals` 建一个目标 → 对比启动前后代码根顶层快照。

**改前**（`git archive HEAD` 快照根 `before_src`，数据根 `before_data`）：

```
statuses: register 200, login 200, create_model 200, chat 200, hire_employee 201, create_goal 200
new_top_level_entries:
  .liuhao_artifacts.db(+shm/wal)   .liuhao_employees.json(+lock)
  .liuhao_execution.journal(+shm/wal)   .liuhao_goals.json(+lock)
  conversation_store.db(+shm/wal)   memory_store.db(+shm/wal)
  personal_context.db(+shm/wal)   data   plugins   __pycache__
new_files_under_data: data/account_usage.sqlite3, data/knowledge_vectors.sqlite3(+shm/wal),
  data/model_registry.sqlite3(+shm/wal)
data_dir_top_level: alerts.json, audit_store.db(+shm/wal), auth_secrets.json(+lock),
  identities.json(+lock), jwt_revocation.db, logs
```

→ 数据根只拿到认证与日志，**所有业务库写回代码根**（审计现场实证一致）。

**改后**（真实仓库根 `after4`，全新 `LIUHAO_DATA_DIR`）：

```
statuses: register 200, login 200, create_model 200, chat 200, hire_employee 201, create_goal 200
new_top_level_entries: []
watched_runtime_files_at_root: []
new_files_under_data: []
changed_watched_stamps: []
data_dir_top_level: account_usage.sqlite3, alerts.json, audit_store.db(+shm/wal),
  auth_secrets.json(+lock), conversation_store.db(+shm/wal), identities.json(+lock),
  jwt_revocation.db, knowledge_vectors.sqlite3(+shm/wal), liuhao_artifacts.db(+shm/wal),
  liuhao_employees.json(+lock), liuhao_execution.journal(+shm/wal), liuhao_goals.json(+lock),
  logs, memory_store.db(+shm/wal), model_registry.sqlite3(+shm/wal), personal_context.db(+shm/wal),
  plugins
```

**改后**（干净副本根 `after_src`，初始无 `data/`、无 `plugins/`，验证"全新目录"也不新建）：

```
new_top_level_entries: []      # 修复前该副本会新建 data/ 与 plugins/
data_dir_top_level: 同上 + plugins、run
```

两点补充：

- `after_src` 副本创建后，另一条并行线的 `ai_management.py` 才加入 `_replace_goal_file`，
  该副本上 `create_goal` 返回 507（代码陈旧，非本次改动引起）；其中 `liuhao_goals.json`
  的落盘路径已是数据目录。真实仓库根（`after4`）上 `create_goal` 返回 200。

## 第二轮实测：只设数据根时的身份 / 审计 / 告警落点

同一探针，清掉**全部**单项覆盖变量与 `LIUHAO_WORKSPACE_ROOT`，只设 `LIUHAO_DATA_DIR`：

```
statuses: register 200, login 200, create_model 200, chat 200, hire_employee 201, create_goal 200
new_top_level_entries: []
rewritten_watched_files: []
new_plugin_jsons: []
resolved:
  identities   <data>\config\human_identities.json   exists
  audit        <data>\audit_store.db                  exists
  alerts       <data>\observability\alerts.json       exists
  auth_secrets <data>\auth_secrets.json               exists
data_dir_files: account_memory.sqlite3, account_usage.sqlite3, audit_store.db(+shm/wal),
  auth_secrets.json(+lock), config/human_identities.json, conversation_store.db(+shm/wal),
  knowledge_vectors.sqlite3(+shm/wal), liuhao_artifacts.db(+shm/wal),
  liuhao_employees.json(+lock), liuhao_execution.journal(+shm/wal),
  liuhao_goals.json(+lock), liuhao_jwt_revocation.db, memory_store.db(+shm/wal),
  model_registry.sqlite3(+shm/wal), observability/alerts.json,
  personal_context.db(+shm/wal), run/local_scheduler.lock
```

身份隔离的**红转绿**证据（不是放宽断言）：

- 修复前：`tests/test_employee_entities.py::test_cross_owner_employees_are_invisible_and_404`
  在 conftest 清空 `LIUHAO_HUMAN_IDENTITIES_FILE` 后，账号树写盘返回 `False` →
  `ACCOUNT_PERSIST_FAILED`。
- 修复后：同文件全绿；并新增
  `tests/kernels/identity/test_human_identity_persistence.py::TestBackendResolution::test_a_data_root_alone_places_the_json_store_inside_it`
  钉住"只设数据根 → 身份文件在数据根内"这一契约；"完全未配置"的两条旧断言改为
  **显式删除 `LIUHAO_DATA_DIR`** 后再断言 `location == ""`，fail-closed 语义不变。

写盘失败的用户可见文案（不是裸错误码）：

> 账号创建失败：账号数据无法写入 `<location>`。请确认该目录存在、当前用户有写权限
> （或把 `LIUHAO_DATA_DIR` 指向一个可写目录）后重试。本次注册已回滚，未发放恢复码。

## 不纳入统一入口（附理由，不假装已修）

1. **`src/gateway/main.py` 的审计 checkpointer 开关**：仍以 `AUDIT_DB_PATH` 是否设置
   为唯一判据，只设数据根时会打印 `AUDIT CHECKPOINTER SKIPPED -- AUDIT_DB_PATH is not set`。
   该文件在本任务的不可动边界内（归其他线）。**审计存储本身**已跟随数据根（见第 21 项），
   缺的只是这处"是否启用 checkpointer"的判定；持该线的同事可把判据扩为
   `AUDIT_DB_PATH or LIUHAO_DATA_DIR`。
2. 插件**源码**目录 [plugins/manager.py](../src/plugins/manager.py) 的
   `plugins_dir.mkdir(...)`：`plugins.path` 指向源码目录（默认 `src/plugins`），不是运行时
   状态；仅在目录缺失时创建，不属于数据落盘问题。
3. `scripts/` 之外的一次性脚本 / 测试产物（`.pytest_*.log`、`verify_metrics.db`、
   `outputs/` 等）不在运行时存储范围内。

## 测试基座护栏（已落地）

[tests/test_data_root_isolation.py](../tests/test_data_root_isolation.py) 两条常驻用例，
不再依赖人记：

1. `test_stores_follow_the_data_root`：清掉所有单项覆盖变量，只设 `LIUHAO_DATA_DIR`，
   断言身份库、审计库、告警库、口令库、JWT 吊销库、模型注册表、联网偏好、情报库、
   ORM 默认 URL 全部解析到数据根内。
2. `test_full_flow_leaves_the_code_root_untouched`：对代码根顶层条目、被监视的运行时
   文件（size + mtime_ns）、`plugins/*.json` 拍快照 → 真实 lifespan 跑一轮
   「建模 / 聊天 / 招员工 / 建目标」→ 断言
   `new_top_level_entries == []`、`rewritten_watched_files == []`、`new_plugin_jsons == []`。

所以以后任何新存储若又按 cwd 相对路径落盘，会直接让这条用例变红，而不是悄悄污染共享目录。
