# 快速开始指南

## 10分钟上手 LiuHao AI OS · 鎏灏智能中枢

### 前置条件

- Python 3.11+
- LiuHao AI OS · 鎏灏智能中枢 已安装
- D:\\LiuHao-AI-OS 目录权限

### 安装步骤

```bash
# 1. 克隆项目
git clone <repository-url>
cd LiuHao-AI-OS

# 2. 创建虚拟环境
python -m venv venv
venv\Scripts\activate

# 3. 安装依赖
pip install -r requirements.txt

# 4. 验证安装
# 优先验证权威审计链 src.kernels.audit（SQLite + 哈希链，设计为防篡改；但运行时链完整性当前 UNVERIFIED——链存在分叉：284 处断链 / 169 行重复 seq，待 F1–F6 修复 + 独立验证后方可断言为完整证据源）。
# 旧路径 src.audit 仍 import 可用，但已弃用、不具防篡改链。
python -c "from src.kernels.audit import AuditStore, verify_audit_integrity; print('Audit kernel importable (SQLite + hash chain, designed tamper-evident; runtime integrity currently UNVERIFIED — forked chain, pending F1-F6 + independent verification)')"
python -c "from src.audit import AuditEvent; print('Audit legacy compat layer importable (deprecated: not tamper-evident)')"
python -c "from src.observability import Span; print('Observability module OK')"
python -c "from src.performance import create_lru_cache; print('Performance module OK')"
python -c "from src.integrations import Base, init_models; print('Integration module OK')"
python -c "from src.plugins.marketplace import Plugin, get_marketplace_store; print('Plugin marketplace OK')"
```

### 基本使用

```python
# 权威审计实现：src.kernels.audit（SQLite + 哈希链，设计为防篡改；但运行时链完整性当前 UNVERIFIED——链存在分叉，待 F1–F6 修复 + 独立验证后方可断言为完整证据源）。
# 旧路径 src.audit 仍可 import，但其事件写入 JSON 文件、不具防篡改链，请勿用于真实审计。
from src.kernels.audit import AuditStore, AuditEventType, AuditScope

# 创建审计事件（示例写入临时库；生产用默认 AuditStore() 落到 audit_store.db；注意该链当前运行时完整性 UNVERIFIED，存在分叉，待修复）
store = AuditStore(db_path="examples/audit_example.db")
store.log_event(AuditEventType.ACCESS_ALLOWED, "user1", AuditScope.L1, "allow",
                details={"note": "login ok"})
store.log_event(AuditEventType.ACCESS_DENIED, "user1", AuditScope.L1, "deny",
                details={"note": "login failed"})
store.log_event(AuditEventType.HUMAN_SOVEREIGNTY_OVERRIDE, "user1", AuditScope.L1,
                "conditional", details={"note": "Failed login attempt"})

# 查看统计与链完整性
stats = store.get_stats()
print(f"总事件数: {stats['total_events']}")
ok, total = store.verify_integrity()
print(f"完整性验证: {ok} (共 {total} 条)")
```

### 第一个插件

```python
from src.plugins.marketplace import Plugin, PluginMetadata, PluginVersion, get_marketplace_store
from src.plugins.sandbox import SandboxExecutionContext, ResourceLimits

# 创建插件元数据
metadata = PluginMetadata(
    name="my-plugin",
    version="1.0.0",
    description="我的第一个插件",
    plugin_type="extension",
    author="LiuHao",
    tags=["demo", "example"]
)

# 创建版本信息
version = PluginVersion(
    version="1.0.0",
    release_notes="初始发布",
    changelog="无",
    upload_url="",
    status="approved"
)

# 创建插件实例
plugin = Plugin(
    plugin_id="my-plugin-001",
    name="my-plugin",
    description="我的第一个插件",
    metadata=metadata,
    current_version=version,
    status="published",
    is_active=True
)

# 注册插件
store = get_marketplace_store()
eid = store.register(plugin)
print(f"插件注册成功: {eid}")

# 创建沙箱执行上下文
context = SandboxExecutionContext(
    execution_id="exec-001",
    plugin_id="my-plugin-001",
    sandbox_id="sandbox-001",
    entry_point="main",
    arguments=["--arg1", "value1"],
    working_directory="/tmp",
    resource_limits=ResourceLimits(
        memory_limit=1024 * 1024,  # 1MB
        execution_time_limit=30,  # 30秒
        network_access=False,
        file_system_access=False
    ),
    timeout=60
)

# 存储上下文
eid2 = store.create_context(context)
print(f"沙箱上下文创建: {eid2}")
```

### 性能基准测试

```python
from src.performance import create_lru_cache, LRUCache

# 创建缓存
cache = create_lru_cache(max_size=100)

# 添加测试数据
for i in range(100):
    cache.put(f"key_{i}", f"value_{i}")

# 测试命中率
hits = 0
misses = 0
for i in range(100):
    if cache.get(f"key_{i}") is not None:
        hits += 1
    else:
        misses += 1

stats = cache.get_stats()
print(f"命中率: {stats.hit_rate:.2%}")
print(f"总请求: {stats.total_requests}")
print(f"缓存大小: {stats.current_size}")
```

### 外部系统集成

```python
from src.integrations import init_models, Base, create_storage_config, create_function_config, create_queue_config

# 创建存储配置
storage_cfg = create_storage_config(
    provider="s3",
    bucket="liuhao-bucket",
    region="ap-north-1",
    access_key="AKID...",
    secret_key="secret..."
)

# 创建函数配置
function_cfg = create_function_config(
    provider="aws",
    function_name="process-data",
    runtime="python3.11",
    handler="handler.main",
    timeout=60,
    memory=256,
    environment={"MODE": "production"}
)

# 创建队列配置
queue_cfg = create_queue_config(
    provider="sqs",
    queue-name="task-queue",
    region="ap-north-1",
    access_key="AKID...",
    secret_key="secret..."
)

print("配置创建成功")
```

### 项目结构

```
LiuHao-AI-OS/
├── src/
│   ├── audit/          # 安全审计
│   ├── observability/  # 观测性
│   ├── performance/    # 性能优化
│   ├── integrations/   # 外部系统集成
│   └── plugins/        # 插件生态
│       ├── marketplace/ # 插件商店
│       ├── sandbox/     # 沙箱运行时
│       └── dependencies/ # 依赖管理
└── docs/
    ├── tutorials/      # 教程
    ├── scenarios/       # 场景案例
    └── best-practices/ # 最佳实践
```

### 进阶技巧

1. **多级缓存**: 结合内存缓存和 Redis 缓存，提升访问速度
2. **插件热重载**: 使用沙箱隔离，支持热插拔而不重启系统
3. **审计链路**: 结合 Trace-ID，实现跨服务完整审计追踪
4. **性能监控**: 使用观测性模块监控关键指标和告警

### 常见问题

| 问题 | 解决方案 |
|------|----------|
| 审计事件未持久化 | 权威审计落在 `audit_store.db`（SQLite 哈希链，设计为防篡改；但当前运行时完整性 UNVERIFIED，存在分叉，待修复）；`src.audit` 遗留层写入 `data/audit/events.json` 且不具防篡改链，请勿用于真实审计 |
| 插件注册失败 | 检查插件元数据是否完整，版本是否冲突 |
| 沙箱超时 | 调整 `ResourceLimits.execution_time_limit` 或优化代码 |
| 缓存命中率低 | 调整 `max_size` 或�查 key 是否一致 |
| ORM 连接失败 | 检查数据库连接串和权限 |

### 升级指南

- **从 v0.x 升级**: 数据库 schema 迁移走 Alembic：`alembic upgrade head`（迁移脚本在 `alembic/versions/`；本仓库没有 `scripts/migrate.py`）
- **插件版本升级**: 在 marketplace 使用 `store.add_version(plugin_id, new_version)`
- **配置变更**: 修改 `config.yaml` 并重启服务

### 许可证

MIT License - 免费用于个人和商业用途