@echo off
rem LiuHao AI OS - command-line troubleshooting entry (--console).
rem Normal users start from the desktop / Start-menu shortcut, which runs
rem runtime\pythonw.exe directly and shows NO console window. This .bat is
rem only for --console troubleshooting on machines without a desktop session.
rem The console code page is switched to UTF-8 so the Chinese messages below
rem are readable on any system locale. This file never parses data-dir.txt
rem (UTF-8 with BOM); only the launcher reads it. Keep the first lines ASCII.
setlocal DisableDelayedExpansion
chcp 65001 >nul
rem Keep the install tree read-only: never write __pycache__ next to the app.
set PYTHONDONTWRITEBYTECODE=1
cd /d "%~dp0"
rem Capture %~dp0 ONCE while delayed expansion is off: the value is stored
rem verbatim even if it contains a literal exclamation mark.
set "LH_DIR=%~dp0"
setlocal EnableDelayedExpansion
rem Every later echo of the install path must use !LH_DIR! (delayed expansion).
rem Percent-expanding an unquoted %~dp0 that contains an ampersand or a caret
rem makes cmd treat the rest of the line as a new command; because a whole IF
rem block is parsed before it runs, even the "runtime missing" branch would
rem break the launcher on a path holding those characters (for example a
rem temporary folder named a+b&c(1)#2 plus a caret).
rem Keep the failure log bounded: retain only the previous failure as .1.
if exist "!LH_DIR!bootstrap.log" move /y "!LH_DIR!bootstrap.log" "!LH_DIR!bootstrap.log.1" >nul 2>nul
rem An explicit LIUHAO_DATA_DIR still wins.
if not exist "runtime\python.exe" (
    echo [FAIL] 安装文件不完整：缺少 runtime\python.exe，程序无法启动。
    echo        修复：重新运行安装包，选择「修复安装」；或重新安装到同一位置（账号与数据会保留）。
    echo        安装位置：!LH_DIR!
    echo        日志：!LH_DIR!bootstrap.log
    echo.
    echo [FAIL] 安装文件不完整：缺少 runtime\python.exe，请重新安装或修复安装。>> "!LH_DIR!bootstrap.log"
    echo 安装位置：!LH_DIR!>> "!LH_DIR!bootstrap.log"
    echo.
    echo 按任意键关闭此窗口。
    pause >nul
    exit /b 1
)
echo 这是命令行排障入口；正常使用请双击桌面快捷方式（不会出现本窗口）。
"runtime\python.exe" "scripts\launch_installed.py" %*
set "LH_CODE=%ERRORLEVEL%"
echo.
if not "%LH_CODE%"=="0" goto :lh_failed
rem 退出码 0 有两种：用户自己停掉服务，或双击时已经有实例在跑（重复启动）。
rem 这两种情况都不该再 pause —— 否则第二个窗口会一直挂着等按键。
exit /b 0
:lh_failed
echo [FAIL] 鎏灏未能正常启动（退出码 %LH_CODE%）。
echo        原因与堆栈见日志：!LH_DIR!bootstrap.log
echo.
echo 按任意键关闭此窗口。
pause >nul
exit /b %LH_CODE%
endlocal
