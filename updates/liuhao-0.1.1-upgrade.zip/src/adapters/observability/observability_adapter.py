"""[LEGACY / NOT WIRED] Observability adapter for LiuHao AI OS.

⚠️ 接线状态（2026-09-13 评审核实）：本模块**未接入运行时**。
全仓没有任何 src/gateway/ 或 src/ai/ 模块 import 它；唯一的引用来自
tests/test_mcp_adapter.py（仅 mcp 子包）。本模块与同目录的 metrics_helper /
tracing 自成一个子包，但整包都未被运行时消费。
网关与 AI 层实际使用的权威可观测性实现位于顶层 ``src/observability/``
（gateway/main.py:23 即 ``from ..observability.tracing import get_tracer``）。

本目录是与权威实现**意图重复、已被取代**的遗留实现（Langfuse/Phoenix 导出封装
在此，但运行时走的是 src/observability）。请勿将其接线进运行时。

（以下为原 docstring）
Integrates metrics, tracing, and structured logging into a single
adapter for easy consumption. Supports Langfuse and Phoenix exports.
"""

import logging
import sys
import time
from typing import Dict, Any, Optional

from .metrics_helper import get_metrics_collector, increment_counter, observe_latency
from .tracing import get_correlation_context

# Langfuse integration
try:
    from langfuse import Langfuse
    from langfuse.utils import ObservationType
    LANGFUSE_AVAILABLE = True
except ImportError:
    LANGFUSE_AVAILABLE = False

# Phoenix integration
try:
    import phoenix  # noqa: F401
    from phoenix.otel import register
    import opentelemetry.sdk  # noqa: F401
    PHOENIX_AVAILABLE = True
except ImportError:
    PHOENIX_AVAILABLE = False


class ObservabilityConfig:
    """Configuration for observability setup."""

    def __init__(
        self,
        enable_metrics: bool = True,
        enable_tracing: bool = True,
        enable_structured_logging: bool = True,
        metrics_endpoint: Optional[str] = None,
        tracing_endpoint: Optional[str] = None,
    ):
        self.enable_metrics = enable_metrics
        self.enable_tracing = enable_tracing
        self.enable_structured_logging = enable_structured_logging
        self.metrics_endpoint = metrics_endpoint
        self.tracing_endpoint = tracing_endpoint


def setup_observability(config: ObservabilityConfig) -> None:
    """Set up the full observability stack."""

    # 1. Configure structured logging
    if config.enable_structured_logging:
        _setup_structured_logging()

    # 2. Initialize metrics
    if config.enable_metrics:
        _init_metrics()

    # 3. Initialize tracing
    if config.enable_tracing:
        _init_tracing()


def _setup_structured_logging() -> None:
    """Set up structured JSON logging."""
    formatter = logging.Formatter(
        '{"timestamp": "%(asctime)s", "level": "%(levelname)s", '
        '"correlation_id": "%(threadName)s", "message": "%(message)s", '
        '"module": "%(module)s", "function": "%(funcName)s", "line": %(lineno)d}'
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.addHandler(handler)

    # Ensure all loggers use the new formatter
    for name in logging.root.manager.loggerDict:
        logger = logging.getLogger(name)
        for handler in logger.handlers:
            handler.setFormatter(formatter)


def _init_metrics() -> None:
    """Initialize metrics collection."""
    get_metrics_collector()
    increment_counter('observability.startup')


def _init_tracing() -> None:
    """Initialize tracing context."""
    ctx = get_correlation_context()
    logging.info(f"Tracing initialized with correlation_id={ctx['correlation_id']}")


def track_latency(name: str, func):
    """Decorator to track function latency."""
    import functools

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        try:
            result = func(*args, **kwargs)
            return result
        finally:
            duration = time.time() - start
            observe_latency(name, duration)
            increment_counter(f'{name}.call')
    return wrapper


# Langfuse export
def export_to_langfuse(trace_data: Dict[str, Any], model_info: Dict[str, Any] = None) -> None:
    """Export trace data to Langfuse observability platform."""
    if not LANGFUSE_AVAILABLE:
        print("⚠ Langfuse not available, skipping export")
        return

    try:
        langfuse = Langfuse()
        observation_type = ObservationType.LLM
        if model_info:
            langfuse.log(
                name=trace_data.get('name', 'unknown'),
                model=model_info.get('model', 'unknown'),
                trace_id=trace_data.get('trace_id'),
                output=trace_data.get('output'),
                usage=model_info.get('usage'),
                input=trace_data.get('input'),
                type=observation_type,
            )
        else:
            langfuse.log(
                name=trace_data.get('name', 'unknown'),
                type=observation_type,
            )
        print(f"✓ Exported to Langfuse: {trace_data.get('name', 'unknown')}")
    except Exception as e:
        print(f"✗ Langfuse export error: {e}")


# Phoenix export
def export_to_phoenix(trace_data: Dict[str, Any]) -> None:
    """Export trace data to Phoenix observability platform."""
    if not PHOENIX_AVAILABLE:
        print("⚠ Phoenix not available, skipping export")
        return

    try:
        # Phoenix uses OpenTelemetry - start Phoenix and get tracer
        tracer_provider = register()
        tracer = tracer_provider.get_tracer(__name__)

        # Create a span for the trace
        with tracer.start_as_current_span(trace_data.get('name', 'unknown')) as span:
            span.set_attribute("input", str(trace_data.get('input', '')))
            span.set_attribute("output", str(trace_data.get('output', '')))
            span.set_attribute("trace_id", trace_data.get('trace_id', ''))
            if 'model' in trace_data:
                span.set_attribute("model", trace_data['model'])

        print(f"✓ Exported to Phoenix: {trace_data.get('name', 'unknown')}")
    except Exception as e:
        print(f"✗ Phoenix export error: {e}")


# OpenTelemetry integration
def init_opentelemetry(
    service_name: str = "liuhao-ai-os",
    endpoint: Optional[str] = None,
    headers: Optional[Dict[str, str]] = None,
) -> None:
    """Initialize OpenTelemetry SDK with OTLP exporter."""
    try:
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
        from opentelemetry.sdk.resources import Resource, SERVICE_NAME
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
        from opentelemetry.instrumentation.logging import LoggingInstrumentor

        # Create resource with service name
        resource = Resource.create({SERVICE_NAME: service_name})

        # Create tracer provider
        provider = TracerProvider(resource=resource)

        # Configure OTLP exporter
        if endpoint:
            otlp_exporter = OTLPSpanExporter(endpoint=endpoint, headers=headers or {})
            provider.add_span_processor(BatchSpanProcessor(otlp_exporter))

        # Set global tracer provider
        trace.set_tracer_provider(provider)

        # Instrument logging
        LoggingInstrumentor().instrument(set_logging_format=True)

        print(f"✓ OpenTelemetry initialized: {service_name}")
    except ImportError:
        print("⚠ OpenTelemetry not available, skipping initialization")
    except Exception as e:
        print(f"✗ OpenTelemetry initialization error: {e}")


def get_tracer(name: str = __name__):
    """Get OpenTelemetry tracer."""
    try:
        from opentelemetry import trace
        return trace.get_tracer(name)
    except ImportError:
        return None


# Global config instance
_config = None


def get_config() -> ObservabilityConfig:
    """Get the global observability config."""
    return _config


def set_config(config: ObservabilityConfig) -> None:
    """Set the global observability config."""
    global _config
    _config = config


# Export key symbols
__all__ = [
    'ObservabilityConfig',
    'setup_observability',
    'track_latency',
    'get_config',
    'set_config',
    'increment_counter',
    'observe_latency',
    'export_to_langfuse',
    'export_to_phoenix',
    'init_opentelemetry',
    'get_tracer',
]
