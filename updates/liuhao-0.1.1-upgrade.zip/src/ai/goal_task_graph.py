"""
Goal → Task Graph Module for LiuHao AI OS

Provides goal decomposition, task chain generation, and execution workflow management.
Supports dependency resolution, circular dependency detection, and parallel execution.
"""

from typing import Dict, List, Any, Optional, Set, Callable
from dataclasses import dataclass, field
from enum import Enum
import uuid
import time
import json
import os
import threading
from collections import defaultdict, deque

from src.common.atomic_write import (
    atomic_write_text,
    exclusive_file_lock,
    read_text_with_retry,
)
from src.common.data_paths import resolve_store_path

from .providers import BaseProvider, get_provider
try:
    from ..observability.metrics import (
        track_goal_decomposition,
        track_task_execution,
    )
except Exception:  # pragma: no cover - metrics backend optional at import time
    # When the metrics backend (prometheus_client) is not installed the planner
    # must still import and run; metrics simply degrade to no-ops. In the normal
    # (venv) environment the import succeeds and behaviour is unchanged.
    def track_goal_decomposition(*_args, **_kwargs):
        return None

    def track_task_execution(*_args, **_kwargs):
        return None
from ..observability.tracing import create_span, end_span, AISpanAttributes
from ..knowledge.memory import create_memory_manager, MemoryTier
from .observability import observe
# The kernel layer is audited via @kernel_action (Policy Controlled + Audited +
# Observable). Importing it here follows the existing src/ai -> src/kernels
# dependency pattern (src/ai/agent_runtime.py, src/ai/liuhao.py already do so).
from src.kernels._crosscutting import kernel_action


class PlannerStateError(RuntimeError):
    """任务图状态落盘失败（调用方不得把这次保存当成成功）。"""


#: 同进程内多实例并发保存同一状态文件时的串行锁。
_STATE_WRITE_LOCK = threading.Lock()


class GoalStatus(Enum):
    """Goal execution status."""
    PENDING = "pending"
    DECOMPOSING = "decomposing"
    DECOMPOSED = "decomposed"
    EXECUTING = "executing"
    COMPLETED = "completed"
    #: Some tasks completed, some failed. Deliberately distinct from COMPLETED:
    #: ``GoalStatus`` is what ``save_state`` persists and ``get_graph_summary``
    #: reports, so folding "partial" into COMPLETED would make a partially-failed
    #: goal indistinguishable from a clean success after a process restart.
    PARTIAL = "partial"
    FAILED = "failed"


class TaskStatus(Enum):
    """Task execution status."""
    PENDING = "pending"
    READY = "ready"           # Dependencies met, waiting for execution
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class GoalDefinition:
    """Represents a high-level goal to be decomposed into tasks."""
    id: str
    description: str
    priority: str = "medium"  # low, medium, high, critical
    status: GoalStatus = GoalStatus.PENDING
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def __post_init__(self):
        if not self.id:
            self.id = f"goal_{uuid.uuid4().hex[:8]}"


@dataclass
class TaskNode:
    """Represents a task in the goal-task graph."""
    id: str
    description: str
    task_type: str = "general"
    depends_on: List[str] = field(default_factory=list)  # Task IDs this task depends on
    status: TaskStatus = TaskStatus.PENDING
    assigned_agent: Optional[str] = None
    result: Optional[Any] = None
    error: Optional[str] = None
    priority: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None

    def __post_init__(self):
        if not self.id:
            self.id = f"task_{uuid.uuid4().hex[:8]}"


class GoalTaskGraph:
    """
    Goal → Task Graph - Decomposes goals into executable task graphs.

    Features:
    - AI-powered goal decomposition
    - Dependency graph construction
    - Topological sorting for execution order
    - Circular dependency detection
    - Parallel execution support
    - Progress tracking
    - Observability integration (metrics, tracing, memory)
    """

    def __init__(
        self,
        provider: Optional[BaseProvider] = None,
        goal: Optional[GoalDefinition] = None,
        max_decomposition_depth: int = 3,
        max_tasks_per_goal: int = 20,
        enable_observability: bool = True,
    ):
        """
        Initialize GoalTaskGraph.

        Args:
            provider: AI provider for decomposition
            goal: Initial goal (can be set later)
            max_decomposition_depth: Maximum recursion depth for decomposition
            max_tasks_per_goal: Maximum tasks to generate per goal
            enable_observability: Enable metrics/tracing/memory integration
        """
        self.provider = provider or get_provider()
        self.goal = goal
        self.max_decomposition_depth = max_decomposition_depth
        self.max_tasks_per_goal = max_tasks_per_goal
        self.enable_observability = enable_observability

        # Task graph storage
        self.tasks: Dict[str, TaskNode] = {}
        self.goal_tasks: Dict[str, List[str]] = defaultdict(list)  # goal_id -> task_ids
        self.task_dependencies: Dict[str, Set[str]] = defaultdict(set)  # task_id -> dependent task_ids

        # Execution state
        self.execution_order: List[str] = []
        self.completed_tasks: Set[str] = set()
        self.failed_tasks: Set[str] = set()

        # Observability
        if self.enable_observability:
            self._memory = create_memory_manager(user_id="goal_task_graph", use_mem0=False)
        else:
            self._memory = None

        # Decomposition prompts
        self.decomposition_prompt_template = """You are an expert task planner. Decompose the following goal into specific, actionable tasks.

Goal: {goal_description}
Priority: {priority}

Generate a JSON array of tasks. Each task should have:
- "id": unique identifier (e.g., "task_1")
- "description": clear, actionable task description
- "type": task type (research, implementation, testing, documentation, review, etc.)
- "depends_on": list of task IDs this task depends on (empty if no dependencies)
- "priority": integer priority (0-10, higher = more important)

Constraints:
- Maximum {max_tasks} tasks
- Tasks should be logically ordered with clear dependencies
- Each task should be independently executable once dependencies are met
- Avoid circular dependencies

Example output format:
[
    {{"id": "task_1", "description": "Research best practices", "type": "research", "depends_on": [], "priority": 8}},
    {{"id": "task_2", "description": "Design architecture", "type": "design", "depends_on": ["task_1"], "priority": 9}},
    {{"id": "task_3", "description": "Implement core module", "type": "implementation", "depends_on": ["task_2"], "priority": 10}}
]"""

    def set_goal(self, goal: GoalDefinition):
        """Set the goal to decompose."""
        self.goal = goal
        self.goal.status = GoalStatus.PENDING

    @observe("goal_task_graph.decompose_goal")
    def decompose_goal(self, goal: Optional[GoalDefinition] = None) -> List[TaskNode]:
        """
        Decompose a goal into a list of tasks using AI.

        Args:
            goal: Goal to decompose (uses self.goal if not provided)

        Returns:
            List of TaskNode objects
        """
        if goal:
            self.set_goal(goal)

        if not self.goal:
            raise ValueError("No goal set for decomposition")

        self.goal.status = GoalStatus.DECOMPOSING

        # Build prompt
        prompt = self.decomposition_prompt_template.format(
            goal_description=self.goal.description,
            priority=self.goal.priority,
            max_tasks=self.max_tasks_per_goal,
        )

        # Use tracing for decomposition
        span = create_span(
            "goal.decompose",
            attributes={
                AISpanAttributes.GOAL_ID: self.goal.id,
                "goal.description": self.goal.description[:200],
                "goal.priority": self.goal.priority,
            }
        )

        start_time = time.time()
        try:
            # Call AI provider with retry
            response = self.provider.generate_with_retry(prompt, temperature=0.3)

            # Parse response
            tasks = self._parse_decomposition_response(response)

            # Create TaskNodes
            task_nodes = []
            for task_data in tasks:
                task = TaskNode(
                    id=task_data.get("id", f"task_{len(task_nodes)}"),
                    description=task_data.get("description", ""),
                    task_type=task_data.get("type", "general"),
                    depends_on=task_data.get("depends_on", []),
                    priority=task_data.get("priority", 0),
                )
                task_nodes.append(task)

            # Store tasks
            self._store_tasks(self.goal.id, task_nodes)

            self.goal.status = GoalStatus.DECOMPOSED
            self.goal.updated_at = time.time()

            # Track metrics
            duration = time.time() - start_time
            track_goal_decomposition("success", duration, len(task_nodes))

            # Persist to memory
            if self.enable_observability and self._memory:
                self._memory.remember(
                    content=f"Goal decomposed: {self.goal.description}",
                    tier=MemoryTier.SEMANTIC,
                    importance=0.9,
                    tags=["goal", "decomposition"],
                    metadata={"goal_id": self.goal.id, "task_count": len(task_nodes)}
                )

            if span:
                end_span(span)

            return task_nodes

        except Exception as e:
            self.goal.status = GoalStatus.FAILED
            self.goal.updated_at = time.time()

            # Track metrics
            duration = time.time() - start_time
            track_goal_decomposition("failed", duration, 0)

            if span:
                end_span(span, error=e)

            raise RuntimeError(f"Goal decomposition failed: {e}")

    def _parse_decomposition_response(self, response: str) -> List[Dict[str, Any]]:
        """Parse AI response into task list."""
        import json
        import re

        # Try to extract JSON from response
        # Look for JSON array in the response
        json_match = re.search(r'\[.*\]', response, re.DOTALL)
        if json_match:
            json_str = json_match.group()
            try:
                return json.loads(json_str)
            except json.JSONDecodeError:
                pass

        # Fallback: try to parse as JSON directly
        try:
            return json.loads(response)
        except json.JSONDecodeError:
            pass

        # Last resort: create fallback tasks
        return self._fallback_decomposition()

    def _fallback_decomposition(self) -> List[Dict[str, Any]]:
        """Create fallback tasks when AI parsing fails."""
        return [
            {"id": "task_1", "description": f"Analyze goal: {self.goal.description}", "type": "analysis", "depends_on": [], "priority": 10},
            {"id": "task_2", "description": "Plan implementation approach", "type": "planning", "depends_on": ["task_1"], "priority": 9},
            {"id": "task_3", "description": "Execute core work", "type": "implementation", "depends_on": ["task_2"], "priority": 8},
            {"id": "task_4", "description": "Verify results", "type": "testing", "depends_on": ["task_3"], "priority": 7},
        ]

    def _store_tasks(self, goal_id: str, tasks: List[TaskNode]):
        """Store tasks in the graph."""
        task_ids = []
        for task in tasks:
            self.tasks[task.id] = task
            task_ids.append(task.id)
            # Build reverse dependency map
            for dep in task.depends_on:
                self.task_dependencies[dep].add(task.id)

        self.goal_tasks[goal_id] = task_ids

    def get_tasks_for_goal(self, goal_id: str) -> List[TaskNode]:
        """Get all tasks for a specific goal."""
        task_ids = self.goal_tasks.get(goal_id, [])
        return [self.tasks[tid] for tid in task_ids if tid in self.tasks]

    def get_execution_order(self, tasks: Optional[List[TaskNode]] = None) -> List[TaskNode]:
        """
        Get topological execution order for tasks.

        Args:
            tasks: Specific tasks to order (defaults to all tasks)

        Returns:
            Tasks in execution order (dependencies first)
        """
        if tasks is None:
            tasks = list(self.tasks.values())

        # Build adjacency list and in-degree count
        task_ids = [t.id for t in tasks]
        adj = defaultdict(list)
        in_degree = {tid: 0 for tid in task_ids}

        for task in tasks:
            for dep in task.depends_on:
                if dep in in_degree:
                    adj[dep].append(task.id)
                    in_degree[task.id] += 1

        # Topological sort (Kahn's algorithm)
        queue = deque([tid for tid in task_ids if in_degree[tid] == 0])
        order = []

        while queue:
            current = queue.popleft()
            order.append(current)

            for neighbor in adj[current]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        # Check for cycles
        if len(order) != len(task_ids):
            # Cycle detected - return best effort order
            remaining = set(task_ids) - set(order)
            order.extend(remaining)

        # Convert back to TaskNode objects
        return [self.tasks[tid] for tid in order if tid in self.tasks]

    def has_cycle(self, tasks: Optional[List[TaskNode]] = None) -> bool:
        """
        Detect if there are circular dependencies in the task graph.

        Args:
            tasks: Specific tasks to check (defaults to all tasks)

        Returns:
            True if cycle detected, False otherwise
        """
        if tasks is None:
            tasks = list(self.tasks.values())

        task_ids = [t.id for t in tasks]
        adj = defaultdict(list)

        for task in tasks:
            for dep in task.depends_on:
                if dep in task_ids:
                    adj[dep].append(task.id)

        # DFS cycle detection
        visited = set()
        rec_stack = set()

        def dfs(node: str) -> bool:
            visited.add(node)
            rec_stack.add(node)

            for neighbor in adj[node]:
                if neighbor not in visited:
                    if dfs(neighbor):
                        return True
                elif neighbor in rec_stack:
                    return True

            rec_stack.remove(node)
            return False

        for task_id in task_ids:
            if task_id not in visited:
                if dfs(task_id):
                    return True

        return False

    def get_ready_tasks(self, tasks: Optional[List[TaskNode]] = None) -> List[TaskNode]:
        """Get tasks that are ready to execute (dependencies met)."""
        if tasks is None:
            tasks = list(self.tasks.values())

        ready = []
        for task in tasks:
            if task.status != TaskStatus.PENDING:
                continue

            # Check if all dependencies are completed
            deps_met = all(
                dep_id in self.completed_tasks
                for dep_id in task.depends_on
            )

            if deps_met:
                task.status = TaskStatus.READY
                ready.append(task)

        return ready

    @observe("goal_task_graph.execute_task")
    def execute_task(self, task_id: str, agent_executor: Callable) -> Dict[str, Any]:
        """
        Execute a single task via the audited ``@kernel_action`` path.

        The real execution work (status transitions + the agent callback) is
        performed by :meth:`_execute_task_audited`, which is decorated with
        ``@kernel_action("ai.execute_planner_task")`` so the planner's
        task-execution loop is now covered by the audit (previously it called
        ``agent_executor`` directly and was orphaned from the audited path).
        """
        return self._execute_task_audited(task_id, agent_executor)

    @kernel_action("ai.execute_planner_task")
    def _execute_task_audited(self, task_id: str, agent_executor: Callable) -> Dict[str, Any]:
        """
        Audited core of a single task's execution.

        Decorated with ``@kernel_action`` so every task run records an honest
        audit event (``outcome`` / ``policy_decision``) via the same
        cross-cutting path used by the kernel layer. The policy posture stays
        record-only (``enforce=False``) -- this is honest auditing, not blocking.
        """
        if task_id not in self.tasks:
            return {"task_id": task_id, "status": "failed", "error": "Task not found"}

        task = self.tasks[task_id]
        task.status = TaskStatus.RUNNING
        task.started_at = time.time()

        # Use tracing for task execution
        span = create_span(
            "task.execute",
            attributes={
                AISpanAttributes.TASK_ID: task_id,
                AISpanAttributes.AGENT_TASK: task.description[:200],
            }
        )

        try:
            # Execute via agent executor -- now inside the audited wrapper.
            # 任务内部的模型调用（prose/network_bus 等）按 task_id 打标签，
            # 这样派活账本可以"总额 = 各任务分项之和"，并落到对应员工/账号。
            from src.ai.usage_meter import label_scope

            with label_scope(f"task:{task_id}"):
                result = agent_executor(task.assigned_agent or "default", task.description)

            task.result = result
            task.status = TaskStatus.COMPLETED
            task.completed_at = time.time()
            self.completed_tasks.add(task_id)

            # Track metrics
            latency_ms = (task.completed_at - task.started_at) * 1000
            track_task_execution(task.task_type, "completed", latency_ms / 1000)

            # Persist to memory
            if self.enable_observability and self._memory:
                self._memory.remember(
                    content=f"Task executed: {task.description}",
                    tier=MemoryTier.EPISODIC,
                    importance=0.7,
                    tags=["task", task.task_type, "completed"],
                    metadata={"task_id": task_id, "result": str(result)[:500]}
                )

            if span:
                end_span(span)

            return {
                "task_id": task_id,
                "status": "completed",
                "result": result,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            task.error = str(e)
            task.status = TaskStatus.FAILED
            task.completed_at = time.time()
            self.failed_tasks.add(task_id)

            # Track metrics
            latency_ms = (task.completed_at - task.started_at) * 1000
            track_task_execution(task.task_type, "failed", latency_ms / 1000)

            # Persist to memory
            if self.enable_observability and self._memory:
                self._memory.remember(
                    content=f"Task failed: {task.description}",
                    tier=MemoryTier.EPISODIC,
                    importance=0.8,
                    tags=["task", task.task_type, "failed"],
                    metadata={"task_id": task_id, "error": str(e)}
                )

            if span:
                end_span(span, error=e)

            return {
                "task_id": task_id,
                "status": "failed",
                "error": str(e),
                "latency_ms": latency_ms,
            }

    @observe("goal_task_graph.execute_graph")
    def execute_graph(
        self,
        goal_id: str,
        agent_executor: callable,
        max_parallel: int = 3,
    ) -> Dict[str, Any]:
        """
        Execute the full task graph for a goal.

        Args:
            goal_id: Goal ID to execute
            agent_executor: Function(agent_id, task_description) -> result
            max_parallel: Maximum parallel executions

        Returns:
            Execution results
        """
        import concurrent.futures
        import contextvars

        tasks = self.get_tasks_for_goal(goal_id)
        if not tasks:
            return {"goal_id": goal_id, "status": "no_tasks", "results": {}}

        self.goal.status = GoalStatus.EXECUTING
        self.completed_tasks.clear()
        self.failed_tasks.clear()

        results = {}
        remaining = set(t.id for t in tasks)

        # Assign agents to tasks (simple round-robin)
        agent_ids = [f"agent_{i}" for i in range(max_parallel)]
        for i, task in enumerate(tasks):
            task.assigned_agent = agent_ids[i % len(agent_ids)]

        with concurrent.futures.ThreadPoolExecutor(max_workers=max_parallel) as executor:
            while remaining:
                # Get ready tasks
                ready = [t for t in tasks if t.id in remaining and self._is_ready(t.id)]

                if not ready:
                    # No task is ready but work remains => the remaining tasks can
                    # never become ready. There are exactly two causes, and BOTH
                    # are terminal:
                    #   (a) a dependency reached a non-completed terminal state
                    #       (failed) -- ``_is_ready`` only accepts deps in
                    #       ``completed_tasks``, so a failed dep blocks forever;
                    #   (b) a dependency cycle.
                    # The previous code only handled (b) and otherwise did
                    # ``time.sleep(0.1); continue`` -- an UNBOUNDED busy-wait that
                    # never terminates: proven hang (a goal whose first task fails
                    # while a second task depends on it spins forever at 10Hz,
                    # holding the thread pool open and the caller never returns).
                    #
                    # Note this is a *provable* deadlock, not a race: every future
                    # submitted in the previous iteration is fully collected by the
                    # ``as_completed`` loop below before control returns here, so
                    # "no ready task" can never be a transient in-flight state.
                    # There is nothing to wait for -- we must terminate honestly.
                    self._fail_blocked_tasks(
                        remaining, tasks, results, cycle=self.has_cycle(
                            [t for t in tasks if t.id in remaining]
                        )
                    )
                    break

                # Submit ready tasks
                future_to_task = {}
                for task in ready[:max_parallel]:
                    remaining.remove(task.id)
                    # 线程池不继承 ContextVar；复制当前上下文，让任务内 provider
                    # 上报的真实 usage 回到本次 Goal 的记账作用域。
                    ctx = contextvars.copy_context()
                    future = executor.submit(
                        ctx.run, self.execute_task, task.id, agent_executor
                    )
                    future_to_task[future] = task.id

                # Collect results
                for future in concurrent.futures.as_completed(future_to_task):
                    tid = future_to_task[future]
                    try:
                        result = future.result()
                        results[tid] = result
                    except Exception as e:
                        results[tid] = {"task_id": tid, "status": "failed", "error": str(e)}

        # Determine overall status
        completed_count = sum(1 for r in results.values() if r.get("status") == "completed")
        failed_count = sum(1 for r in results.values() if r.get("status") == "failed")

        if failed_count == 0:
            self.goal.status = GoalStatus.COMPLETED
            overall_status = "completed"
        elif completed_count == 0:
            self.goal.status = GoalStatus.FAILED
            overall_status = "failed"
        else:
            # Partial success must NOT be recorded as COMPLETED: ``goal.status`` is
            # what ``save_state`` persists and what ``get_graph_summary`` reports,
            # so stamping COMPLETED on a partially-failed goal makes a partial
            # failure indistinguishable from a clean success after a restart.
            self.goal.status = GoalStatus.PARTIAL
            overall_status = "partial"

        self.goal.updated_at = time.time()

        return {
            "goal_id": goal_id,
            "goal_description": self.goal.description,
            "status": overall_status,
            "total_tasks": len(tasks),
            "completed": completed_count,
            "failed": failed_count,
            "results": results,
            "execution_order": [t.id for t in self.get_execution_order(tasks)],
        }

    def _fail_blocked_tasks(
        self,
        remaining: Set[str],
        tasks: List[TaskNode],
        results: Dict[str, Any],
        *,
        cycle: bool,
    ) -> None:
        """Terminally fail every task that can never become ready.

        Called from :meth:`execute_graph` when no remaining task is ready. Each
        blocked task is failed with the *actual* reason it is blocked -- a failed
        dependency (transitively), a dependency that does not exist, or a cycle --
        rather than a single blanket message. "Marked failed" is not the same as
        "we know why it failed", and the reason is what makes the resulting goal
        failure diagnosable from the outside.
        """
        for tid in sorted(remaining):
            task = self.tasks[tid]
            if cycle:
                error = "Circular dependency detected"
            else:
                error = self._describe_block(tid)
            task.status = TaskStatus.FAILED
            task.error = error
            task.completed_at = time.time()
            self.failed_tasks.add(tid)
            results[tid] = {"task_id": tid, "status": "failed", "error": error}

    def _describe_block(self, task_id: str) -> str:
        """Explain why ``task_id`` can never run, naming the offending dep."""
        task = self.tasks.get(task_id)
        if task is None:  # pragma: no cover - defensive
            return "Task not found"
        for dep in task.depends_on:
            if dep in self.failed_tasks:
                return f"Blocked: dependency '{dep}' failed"
            dep_task = self.tasks.get(dep)
            if dep_task is None:
                return f"Blocked: dependency '{dep}' does not exist"
            if dep_task.status not in (TaskStatus.COMPLETED,):
                return (
                    f"Blocked: dependency '{dep}' is "
                    f"{dep_task.status.value}, never completed"
                )
        return "Blocked: dependencies can never be satisfied"

    def _is_ready(self, task_id: str) -> bool:
        """Check if task is ready to execute."""
        task = self.tasks.get(task_id)
        if not task or task.status != TaskStatus.PENDING:
            return False
        return all(dep_id in self.completed_tasks for dep_id in task.depends_on)

    def get_graph_summary(self, goal_id: str) -> Dict[str, Any]:
        """Get summary of the task graph for a goal."""
        tasks = self.get_tasks_for_goal(goal_id)

        if not tasks:
            return {"goal_id": goal_id, "task_count": 0}

        type_counts = defaultdict(int)
        for task in tasks:
            type_counts[task.task_type] += 1

        return {
            "goal_id": goal_id,
            "goal_description": self.goal.description if self.goal else "unknown",
            "goal_status": self.goal.status.value if self.goal else "unknown",
            "task_count": len(tasks),
            "task_types": dict(type_counts),
            "has_cycle": self.has_cycle(tasks),
            "execution_order": [t.id for t in self.get_execution_order(tasks)],
            "completed": len([t for t in tasks if t.id in self.completed_tasks]),
            "failed": len([t for t in tasks if t.id in self.failed_tasks]),
            "pending": len([t for t in tasks if t.status == TaskStatus.PENDING]),
        }

    # ------------------------------------------------------------------ #
    # Durable persistence (restart recovery) -- stdlib json only, no deps.
    # ------------------------------------------------------------------ #
    @staticmethod
    def _default_state_path() -> str:
        """Default location for the persisted planner state.

        ``LIUHAO_WORKSPACE_ROOT`` > ``LIUHAO_DATA_DIR`` > repo-root fallback
        (see ``src.common.data_paths``), so isolation runs never write to the
        shared development tree.
        """
        repo_root = os.path.dirname(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        )
        return resolve_store_path(
            "planner_state.json",
            os.path.join(repo_root, ".planner_state.json"),
            workspace=True,
        )

    def _serialize_goal(self, goal: Optional[GoalDefinition]) -> Optional[Dict[str, Any]]:
        if goal is None:
            return None
        return {
            "id": goal.id,
            "description": goal.description,
            "priority": goal.priority,
            "status": goal.status.value,
            "metadata": goal.metadata,
            "created_at": goal.created_at,
            "updated_at": goal.updated_at,
        }

    def _serialize_task(self, task: TaskNode) -> Dict[str, Any]:
        # result may be an arbitrary object; keep it JSON-safe or fall back to a
        # stringified form so the dump never raises during restart recovery.
        try:
            json.dumps(task.result)
            result = task.result
        except (TypeError, ValueError):
            result = {"__unserializable__": str(task.result)}
        return {
            "id": task.id,
            "description": task.description,
            "task_type": task.task_type,
            "depends_on": list(task.depends_on),
            "status": task.status.value,
            "assigned_agent": task.assigned_agent,
            "result": result,
            "error": task.error,
            "priority": task.priority,
            "metadata": task.metadata,
            "created_at": task.created_at,
            "started_at": task.started_at,
            "completed_at": task.completed_at,
        }

    @staticmethod
    def _read_persisted_state(path: str) -> Dict[str, Any]:
        """写事务内重读磁盘状态。

        读不到（不存在）返回空字典；读失败/损坏必须抛错 —— 用空快照覆盖
        唯一副本会让整张任务图消失。
        """
        if not os.path.exists(path):
            return {}
        try:
            data = json.loads(read_text_with_retry(path))
        except Exception as exc:  # noqa: BLE001 - corrupt state must fail closed
            raise PlannerStateError(
                f"读取任务图状态失败（{path}）：{type(exc).__name__}: {exc}；"
                "为避免覆盖唯一副本，本次写入已拒绝"
            ) from exc
        if not isinstance(data, dict):
            raise PlannerStateError(
                f"任务图状态结构不合法（{path}）：期望 JSON 对象，"
                f"实际 {type(data).__name__}；本次写入已拒绝"
            )
        return data

    @staticmethod
    def _merge_state_documents(
        disk: Dict[str, Any], memory: Dict[str, Any]
    ) -> Dict[str, Any]:
        """把本实例的目标态合并进磁盘现状。

        * 同一个 goal id（或磁盘为空/无 goal）：按 task id 合并 —— 磁盘上
          另一个写入者新增、本实例还不知道的任务保留，同一 id 以内存为准
          （内存是这个图当前的目标态，完成/失败状态不会被磁盘旧值回退）；
        * 不同 goal id：这是另一个任务的图，整份替换。把上一个目标的任务
          混进新目标会破坏依赖图，比"后写者覆盖"更糟；
        * **终态不可回退**：任务的 COMPLETED/FAILED/SKIPPED、目标的
          COMPLETED/FAILED/PARTIAL 一旦落盘就不能被一个持旧快照的并发写入者
          改回 PENDING/RUNNING。状态流转本身是单向的，单调合并既防止已完成
          的任务被回退，又不阻塞"PENDING → COMPLETED"这类正常推进。
        """
        if not isinstance(disk, dict) or not disk:
            return memory
        disk_goal = disk.get("goals")
        memory_goal = memory.get("goals")
        if (
            isinstance(disk_goal, dict)
            and isinstance(memory_goal, dict)
            and disk_goal.get("id") != memory_goal.get("id")
        ):
            return memory

        terminal_task = {
            TaskStatus.COMPLETED.value,
            TaskStatus.FAILED.value,
            TaskStatus.SKIPPED.value,
        }
        tasks: Dict[str, Dict[str, Any]] = {}
        for item in disk.get("tasks") or []:
            if isinstance(item, dict) and item.get("id"):
                tasks[item["id"]] = item
        for item in memory.get("tasks") or []:
            if not (isinstance(item, dict) and item.get("id")):
                continue
            existing = tasks.get(item["id"])
            # 磁盘已是终态，而内存持有的是非终态旧快照：保留磁盘，不回退。
            if (
                isinstance(existing, dict)
                and existing.get("status") in terminal_task
                and item.get("status") not in terminal_task
            ):
                continue
            tasks[item["id"]] = item

        terminal_goal = {
            GoalStatus.COMPLETED.value,
            GoalStatus.FAILED.value,
            GoalStatus.PARTIAL.value,
        }
        if (
            isinstance(disk_goal, dict)
            and isinstance(memory_goal, dict)
            and disk_goal.get("id") == memory_goal.get("id")
            and disk_goal.get("status") in terminal_goal
            and memory_goal.get("status") not in terminal_goal
        ):
            merged_goal = disk_goal
        else:
            merged_goal = memory_goal if memory_goal is not None else disk_goal

        return {
            "version": memory.get("version", 1),
            "goals": merged_goal,
            "tasks": list(tasks.values()),
        }

    def save_state(self, path: Optional[str] = None) -> str:
        """Persist goals + tasks to a JSON file.

        Returns the path written. Uses only the stdlib ``json`` module so no
        third-party dependency is introduced. Call this after (or during)
        execution so a process restart can recover the graph via
        :meth:`load_state`.

        写入事务：进程锁 → OS 文件锁 → 锁内重读磁盘并按 task id 做目标态合并
        → 唯一临时文件 + fsync + 重试 replace。失败抛
        :class:`PlannerStateError`，不会"返回路径但文件是半截/被覆盖"。
        """
        path = path or self._default_state_path()
        data = {
            "version": 1,
            "goals": self._serialize_goal(self.goal),
            "tasks": [self._serialize_task(t) for t in self.tasks.values()],
        }
        with _STATE_WRITE_LOCK:
            with exclusive_file_lock(f"{path}.lock", description="任务图状态"):
                merged = self._merge_state_documents(
                    self._read_persisted_state(path), data
                )
                try:
                    atomic_write_text(
                        path, json.dumps(merged, ensure_ascii=False, indent=2)
                    )
                except Exception as exc:  # noqa: BLE001
                    raise PlannerStateError(
                        f"任务图状态写入失败（{path}）：{type(exc).__name__}: "
                        f"{exc}；本次修改未落盘"
                    ) from exc
        return path

    @classmethod
    def load_state(
        cls, path: Optional[str] = None, **init_kwargs: Any
    ) -> "GoalTaskGraph":
        """Load a previously saved planner state into a fresh instance.

        The restored instance carries the same goal id, task ids, statuses,
        dependency edges and completion sets, enabling recovery across a
        process restart. ``**init_kwargs`` are forwarded to the constructor
        (e.g. ``enable_observability=False``).
        """
        resolved = path or cls._default_state_path()
        if not os.path.exists(resolved):
            raise FileNotFoundError(f"planner state not found: {resolved}")
        data = json.loads(read_text_with_retry(resolved))

        graph = cls(**init_kwargs)
        goal_data = data.get("goals")
        if goal_data:
            graph.goal = GoalDefinition(
                id=goal_data["id"],
                description=goal_data.get("description", ""),
                priority=goal_data.get("priority", "medium"),
                status=GoalStatus(goal_data.get("status", "pending")),
                metadata=goal_data.get("metadata", {}) or {},
                created_at=goal_data.get("created_at", time.time()),
                updated_at=goal_data.get("updated_at", time.time()),
            )
        for td in data.get("tasks", []):
            task = TaskNode(
                id=td["id"],
                description=td.get("description", ""),
                task_type=td.get("task_type", "general"),
                depends_on=list(td.get("depends_on", []) or []),
                status=TaskStatus(td.get("status", "pending")),
                assigned_agent=td.get("assigned_agent"),
                result=td.get("result"),
                error=td.get("error"),
                priority=td.get("priority", 0),
                metadata=td.get("metadata", {}) or {},
                created_at=td.get("created_at", time.time()),
                started_at=td.get("started_at"),
                completed_at=td.get("completed_at"),
            )
            graph.tasks[task.id] = task
            if graph.goal is not None:
                graph.goal_tasks[graph.goal.id].append(task.id)
                for dep in task.depends_on:
                    graph.task_dependencies[dep].add(task.id)
            if task.status == TaskStatus.COMPLETED:
                graph.completed_tasks.add(task.id)
            elif task.status == TaskStatus.FAILED:
                graph.failed_tasks.add(task.id)
        return graph


# Convenience function for quick goal decomposition
def decompose_goal(
    description: str,
    priority: str = "medium",
    provider: Optional[BaseProvider] = None,
) -> List[TaskNode]:
    """
    Quick function to decompose a goal into tasks.

    Args:
        description: Goal description
        priority: Goal priority
        provider: AI provider (optional)

    Returns:
        List of TaskNode objects
    """
    graph = GoalTaskGraph(provider=provider)
    goal = GoalDefinition(
        id=f"goal_{uuid.uuid4().hex[:8]}",
        description=description,
        priority=priority,
    )
    return graph.decompose_goal(goal)
